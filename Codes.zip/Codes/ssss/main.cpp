#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846
void display()
{
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);
		GLfloat x=0.0f; GLfloat y=0.0f; GLfloat radius =.1f;
	int i;
	int lineAmount = 100;
	float twicePi = 2.0f * PI;
int j=0;


	//glBegin(GL_LINE_LOOP);
	for(j=0;j<9;j++)
    {
      glBegin(GL_LINE_LOOP);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
		 //glEnd();
    glLoadIdentity();
		radius +=.1;
		glEnd();
    }
    //glEnd();


    radius =.1f;
    int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(237, 244, 24);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();
		////////////////////////
		int i2;

//translated circles start////       1

glScalef(.25f,.25f,0.0f);
glTranslatef(.5f,.6f,0.0f);

    radius =.1f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(249, 242, 242);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		//translated circles End////     2
    glLoadIdentity();

     glScalef(.35f,.35f,0.0f);
glTranslatef(-.55f,-.65f,0.0f);

    radius =.1f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(221, 113, 55);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		//translated circles End////



		//translated circles End////   3
    glLoadIdentity();

     glScalef(.45f,.45f,0.0f);
glTranslatef(.6f,-.6f,0.0f);
//glColor3ub(221, 113, 55);
    radius =.1f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(35, 186, 108);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		//translated circles End////


				//translated circles End////   4
    glLoadIdentity();

     glScalef(.5f,.5f,0.0f);
glTranslatef(-.5f,-.85f,0.0f);

    radius =.1f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(186, 35, 35);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		//translated circles End////

						//translated circles End////    5
    glLoadIdentity();

     glScalef(.90f,.90f,0.0f);
glTranslatef(-.65f,.2f,0.0f);
//glColor3ub(221, 113, 55);
    radius =.1f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(232, 187, 53);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		//translated circles End////


   //translated circles End////   6
    glLoadIdentity();

     glScalef(.65f,.65f,0.0f);
glTranslatef(.8f,.750f,0.0f);
//glColor3ub(221, 113, 55);
    radius =.1f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(122, 88, 1);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		//translated circles End////



            //translated circles End////    7
    glLoadIdentity();

     glScalef(.5f,.5f,0.0f);
glTranslatef(-.8f,1.35f,0.0f);
//glColor3ub(221, 113, 55);
    radius =.1f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(74, 117, 219);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		//translated circles End////


   //translated circles End////   8
    glLoadIdentity();

     glScalef(.75f,.75f,0.0f);
glTranslatef(.90f,-.8f,0.0f);
//glColor3ub(221, 113, 55);
    radius =.1f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(174, 252, 234);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		//translated circles End////


	glFlush();
}


/* Main function: GLUT runs as a console application starting at main()  */
int main(int argc, char** argv) {
	glutInit(&argc, argv);                 // Initialize GLUT
	glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
	glutInitWindowSize(320, 320);   // Set the window's initial width & height

	glutDisplayFunc(display); // Register display callback handler for window re-paint

	glutMainLoop();           // Enter the event-processing loop
	return 0;
}
