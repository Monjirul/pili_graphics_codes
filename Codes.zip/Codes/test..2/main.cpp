#include <windows.h>
#include <GL/glut.h>
#include<math.h>>
# define PI           3.14159265358979323846

void display() {
glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
glClear(GL_COLOR_BUFFER_BIT);
int i;
//sun
GLfloat x=.0f; GLfloat y=.0f; GLfloat radius =.075f;
int triangleAmount = 20;

GLfloat twicePi = 2.0f * PI;
    glColor3ub(252, 212, 64);
glBegin(GL_TRIANGLE_FAN);
glVertex2f(x, y);

for(i = 0; i <= triangleAmount;i++) {
glVertex2f(
            x + (radius * cos(i *  twicePi / triangleAmount)),
    y + (radius * sin(i * twicePi / triangleAmount))
);
}
glEnd();

//mercury
GLfloat x2=.0f; GLfloat y2=.0f; GLfloat radius2 =.15f;
int i2;
int lineAmount2 = 100; //# of triangles used to draw circle

//GLfloat radius = 0.8f; //radius
GLfloat twicePi2 = 2.0f * PI;
    glColor3ub(255, 255, 255);
glBegin(GL_LINE_LOOP);
for(i2 = 0; i2 <= lineAmount2;i2++) {
glVertex2f(
    x2 + (radius2 * cos(i2 *  twicePi2 / lineAmount2)),
    y2 + (radius2* sin(i2 * twicePi2 / lineAmount2))
);
}
glEnd();
    glLoadIdentity();

//venus
    glScalef(1.5f,1.5f,0.0f);
    glColor3ub(255, 255, 255);
glBegin(GL_LINE_LOOP);
for(i2 = 0; i2 <= lineAmount2;i2++) {
glVertex2f(
    x2 + (radius2 * cos(i2 *  twicePi2 / lineAmount2)),
    y2 + (radius2* sin(i2 * twicePi2 / lineAmount2))
);
}
glEnd();
    glLoadIdentity();

//earth
glScalef(2.2f,2.2f,0.0f);
glColor3ub(255, 255, 255);
glBegin(GL_LINE_LOOP);
for(i2 = 0; i2 <= lineAmount2;i2++) {
glVertex2f(
    x2 + (radius2 * cos(i2 *  twicePi2 / lineAmount2)),
    y2 + (radius2* sin(i2 * twicePi2 / lineAmount2))
);
}
glEnd();
    glLoadIdentity();

//mars
glScalef(2.9f,2.9f,0.0f);
glColor3ub(255, 255, 255);
glBegin(GL_LINE_LOOP);
for(i2 = 0; i2 <= lineAmount2;i2++) {
glVertex2f(
    x2 + (radius2 * cos(i2 *  twicePi2 / lineAmount2)),
    y2 + (radius2* sin(i2 * twicePi2 / lineAmount2))
);
}
glEnd();
    glLoadIdentity();
//jupiter
glScalef(3.6f,3.6f,0.0f);
glColor3ub(255, 255, 255);
glBegin(GL_LINE_LOOP);
for(i2 = 0; i2 <= lineAmount2;i2++) {
glVertex2f(
    x2 + (radius2 * cos(i2 *  twicePi2 / lineAmount2)),
    y2 + (radius2* sin(i2 * twicePi2 / lineAmount2))
);
}
glEnd();
    glLoadIdentity();
//saturn
glScalef(4.3f,4.3f,0.0f);
glColor3ub(255, 255, 255);
glBegin(GL_LINE_LOOP);
for(i2 = 0; i2 <= lineAmount2;i2++) {
glVertex2f(
    x2 + (radius2 * cos(i2 *  twicePi2 / lineAmount2)),
    y2 + (radius2* sin(i2 * twicePi2 / lineAmount2))
);
}
glEnd();
    glLoadIdentity();
//uranus
glScalef(5.0f,5.0f,0.0f);
glColor3ub(255, 255, 255);
glBegin(GL_LINE_LOOP);
for(i2 = 0; i2 <= lineAmount2;i2++) {
glVertex2f(
    x2 + (radius2 * cos(i2 *  twicePi2 / lineAmount2)),
    y2 + (radius2* sin(i2 * twicePi2 / lineAmount2))
);
}
glEnd();
    glLoadIdentity();
//neptune

glScalef(5.7f,5.7f,0.0f);
glColor3ub(255, 255, 255);
glBegin(GL_LINE_LOOP);
for(i2 = 0; i2 <= lineAmount2;i2++) {
glVertex2f(
    x2 + (radius2 * cos(i2 *  twicePi2 / lineAmount2)),
    y2 + (radius2* sin(i2 * twicePi2 / lineAmount2))
);
}
glEnd();
    glLoadIdentity();

    //mercury

    x=.1f; y=.1f; radius =.04f;
    glColor3ub(151, 151, 159);
    glBegin(GL_TRIANGLE_FAN);
glVertex2f(x, y);

for(i = 0; i <= triangleAmount;i++) {
glVertex2f(
            x + (radius * cos(i *  twicePi / triangleAmount)),
    y + (radius * sin(i * twicePi / triangleAmount))
);
}
glEnd();
    glLoadIdentity();
//venus
     glTranslatef(-.28f,.02f,0.0f);
    x=.1f; y=.1f; radius =.04f;
    glColor3ub(239, 239, 239);
    glBegin(GL_TRIANGLE_FAN);
glVertex2f(x, y);

for(i = 0; i <= triangleAmount;i++) {
glVertex2f(
            x + (radius * cos(i *  twicePi / triangleAmount)),
    y + (radius * sin(i * twicePi / triangleAmount))
);
}
glEnd();
glLoadIdentity();

    //earth
glTranslatef(.17f,-.27f,0.0f);
    x=.1f; y=.1f; radius =.05f;
    glColor3ub(71, 96, 137);
    glBegin(GL_TRIANGLE_FAN);
glVertex2f(x, y);

for(i = 0; i <= triangleAmount;i++) {
glVertex2f(
            x + (radius * cos(i *  twicePi / triangleAmount)),
    y + (radius * sin(i * twicePi / triangleAmount))
);
}
glEnd();
glLoadIdentity();

    //mars
glTranslatef(.34f,-.07f,0.0f);
    x=.1f; y=.1f; radius =.045f;
    glColor3ub(183, 88, 20);
    glBegin(GL_TRIANGLE_FAN);
glVertex2f(x, y);

for(i = 0; i <= triangleAmount;i++) {
glVertex2f(
            x + (radius * cos(i *  twicePi / triangleAmount)),
    y + (radius * sin(i * twicePi / triangleAmount))
);
}
glEnd();
glLoadIdentity();
//jupiter
glTranslatef(-.34f,-.57f,0.0f);
    x=.1f; y=.1f; radius =.07f;
    glColor3ub(160, 111, 77);
    glBegin(GL_TRIANGLE_FAN);
glVertex2f(x, y);

for(i = 0; i <= triangleAmount;i++) {
glVertex2f(
            x + (radius * cos(i *  twicePi / triangleAmount)),
    y + (radius * sin(i * twicePi / triangleAmount))
);
}
glEnd();
glLoadIdentity();

//saturn

glTranslatef(-.34f,.5f,0.0f);
    x=.1f; y=.1f; radius =.055f;
    glColor3ub(173, 171, 171);
    glBegin(GL_TRIANGLE_FAN);
glVertex2f(x, y);

for(i = 0; i <= triangleAmount;i++) {
glVertex2f(
            x + (radius * cos(i *  twicePi / triangleAmount)),
    y + (radius * sin(i * twicePi / triangleAmount))
);
}
glEnd();
glLoadIdentity();



//uranus
glTranslatef(-.83f,.05f,0.0f);
    x=.1f; y=.1f; radius =.05f;
    glColor3ub(6, 229, 229);
    glBegin(GL_TRIANGLE_FAN);
glVertex2f(x, y);

for(i = 0; i <= triangleAmount;i++) {
glVertex2f(
            x + (radius * cos(i *  twicePi / triangleAmount)),
    y + (radius * sin(i * twicePi / triangleAmount))
);
}
glEnd();
glLoadIdentity();

//neptune
glTranslatef(.65f,-.5f,0.0f);
    x=.1f; y=.1f; radius =.047f;
    glColor3ub(2, 67, 102);
    glBegin(GL_TRIANGLE_FAN);
glVertex2f(x, y);

for(i = 0; i <= triangleAmount;i++) {
glVertex2f(
            x + (radius * cos(i *  twicePi / triangleAmount)),
    y + (radius * sin(i * twicePi / triangleAmount))
);
}
glEnd();
glLoadIdentity();



glFlush();
}

int main(int argc, char** argv) {
glutInit(&argc, argv);
glutCreateWindow("OpenGL Setup Test");
glutInitWindowSize(320, 320);
glutDisplayFunc(display);
glutMainLoop();
return 0;
}
