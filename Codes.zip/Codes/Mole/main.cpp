#include<cstdio>

#include <GL/gl.h>
//#include <GL/glut.h>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846


void Mole()
{
    //hole
    glBegin(GL_QUADS); // 9
     //glColor3ub(1, 1, 0);
    glColor3ub(114, 45, 10);
    glVertex2f(.35f,.3f);
    glVertex2f(.55f,.3f);
    glVertex2f(.55f,.1f);
    glVertex2f(.35f,.1f);
    glEnd();

//mole body
    GLfloat x=0.45f; GLfloat y=0.225f;
	int i;
	float twicePi = 2.0f * PI;
   GLfloat radius =.07f;
    int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(146, 154, 168);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();


    glBegin(GL_QUADS); // 9
     //glColor3ub(1, 1, 0);
    glColor3ub(146, 154, 168);
    glVertex2f(.38f,.12f);
    glVertex2f(.52f,.12f);
    glVertex2f(.52f,.22f);
    glVertex2f(.38f,.22f);
    glEnd();

    ////mole body end

//left eye
      x=0.42f; y=0.225f;
	 i;
	 twicePi = 2.0f * PI;
    radius =.02f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(234, 236, 239);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();
	//right eye

		  x=0.48f; y=0.225f;
	 i;
	 twicePi = 2.0f * PI;
    radius =.02f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(234, 236, 239);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();
//eye part
    glLineWidth(7.5);
    glBegin(GL_LINES);
	glColor3ub(15, 7, 3);
	glVertex2f(0.43f, 0.23f);    // x, y
	glVertex2f(0.43f, 0.215f);

	glVertex2f(0.473f, 0.23f);    // x, y
	glVertex2f(0.473f, 0.215f);
   glEnd();
//nose
  	  x=0.45f; y=0.2f;
	 i;
	 twicePi = 2.0f * PI;
    radius =.02f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(239, 87, 11);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

//teeth
    glLineWidth(5);
    glBegin(GL_LINES);
	glColor3ub(234, 236, 239);
	glVertex2f(0.442f, 0.175f);    // x, y
	glVertex2f(0.442f, 0.145f);

	glVertex2f(0.46f, 0.175f);    // x, y
	glVertex2f(0.46f, 0.145f);
   glEnd();

   glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(234, 236, 239);
	glVertex2f(0.4f, 0.175f);    // x, y
	glVertex2f(0.44f, 0.19f);


	glVertex2f(0.457f, 0.19f);
	glVertex2f(0.493f, 0.175f);    // x, y
	glEnd();

		}





void display()
 {
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
   glClear(GL_COLOR_BUFFER_BIT);


  Mole();

glutSwapBuffers();
  glFlush();
}




int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitWindowSize(1000, 660);
   glutInitWindowPosition(50, 50);
   glutCreateWindow("Basic Animation");
   glutDisplayFunc(display);
//   init();
  // glutKeyboardFunc(handleKeypress);
  //glutMouseFunc(handleMouse);
 // glutTimerFunc(100, update, 0);
   glutMainLoop();
   return 0;
}
