#include<cstdio>
#include <GL/gl.h>
#include <GL/glut.h>


GLfloat position = 0.0f;
GLfloat revpos2 = 0.0f;
GLfloat speed = 0.05f;
GLfloat Cloudpos = 0.1f;
GLfloat Spos = 0.0f;
void update(int value) {

    if(position < -1.0)
        position = 1.2f;

    if(revpos2 > 1.0)
        revpos2 = -1.2f;
  if(Cloudpos > 1.0)
        Cloudpos = -1.2f;

    revpos2 += speed;
    position -= speed;
Cloudpos += speed;

	glutPostRedisplay();


	glutTimerFunc(100, update, 0);
}
void init() {
   glClearColor(0.0f, 1.0f, 1.0f, 1.0f);
}

void handleMouse(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON)
	{
		if (state == GLUT_DOWN)
		{
			speed += 0.1f;
			printf("clicked at (%d, %d)\n", x, y);
		}
	}

	glutPostRedisplay();
}

void handleKeypress(unsigned char key, int x, int y) {

	switch (key) {

case 'a':
    speed = 0.0f;
    break;
case 'w':
    speed = 0.1f;
    break;


glutPostRedisplay();


	}
}






void SailorL()
{

    glColor3ub(255, 239, 66);
    glutSolidSphere(0.025,20,20);


   glBegin(GL_TRIANGLES);
    glColor3ub(76, 45, 1);
   glVertex2f(0.0f, -0.025f);
    glVertex2f( -0.07f, -0.07f);
    glVertex2f( 0.07f,  -0.07f);
glEnd();


  glBegin(GL_QUADS);
    glColor3ub(38, 37, 37);
    glVertex2f(0.09f, 0.03f);
    glVertex2f(0.1f, 0.03f);
    glVertex2f( -0.04f, -0.15f);
    glVertex2f( -0.05f, -0.15f);
  glEnd();


}

void SailorR()
{

    glColor3ub(255, 239, 66);
    glutSolidSphere(0.025,20,20);


   glBegin(GL_TRIANGLES);
    glColor3ub(76, 45, 1);
   glVertex2f(0.0f, -0.025f);
    glVertex2f( -0.07f, -0.07f);
    glVertex2f( 0.07f,  -0.07f);
glEnd();


  glBegin(GL_QUADS);
    glColor3ub(38, 37, 37);
    glVertex2f(-0.09f, 0.03f);
    glVertex2f(-0.1f, 0.03f);
    glVertex2f( 0.04f, -0.15f);
    glVertex2f( 0.05f, -0.15f);
  glEnd();


}

void ShipMEL()
{
    glLoadIdentity();
    glTranslatef(position-.7f,-0.635f, 0.0f);

   SailorR();


    glLoadIdentity();
    glPushMatrix();
    glTranslatef(position,0.0f, 0.0f);

 glBegin(GL_POLYGON);

    glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(-0.7f, -0.8f);
    glVertex2f( -0.4f, -0.8f);
    glVertex2f( -0.3f,  -0.7f);
    glVertex2f( -0.8f,  -0.7f);
    glVertex2f(-0.7f,  -0.8f);

    glEnd();


    glBegin(GL_QUADS);//roof
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(-0.55f,-0.7f);
    glVertex2f(-0.55f,-0.65f);
    glVertex2f(-0.54f,-0.65f);
    glVertex2f(-0.54f,-0.-.7f);

    glEnd();


    glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 1.0f, 0.0f);

    glVertex2f(-0.65f,-.65f);
    glVertex2f(-0.6f,-0.5f);
    glVertex2f(-0.35f,-0.5f);
    glVertex2f(-0.4f,-.65f);

    glEnd();
    glLoadIdentity();
    glTranslatef(position-0.55f,-0.81f, 0.0f);
    glColor3ub(8, 67, 163);
    glutSolidSphere(0.07,20,20);
     glLoadIdentity();
    glTranslatef(position-0.65f,-0.8f, 0.0f);
    glColor3ub(8, 67, 163);
    glutSolidSphere(0.07,20,20);
        glLoadIdentity();
    glTranslatef(position-0.45f,-0.8f, 0.0f);
    glColor3ub(8, 67, 163);
    glutSolidSphere(0.07,20,20);

}




void ShipMER()
{
    glLoadIdentity();
    glTranslatef(revpos2-.4f,-0.635f+0.6f, 0.0f);

   SailorR();


    glLoadIdentity();
    glPushMatrix();
    glTranslatef(revpos2,0.6f, 0.0f);

 glBegin(GL_POLYGON);

    glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(-0.7f, -0.8f);
    glVertex2f( -0.4f, -0.8f);
    glVertex2f( -0.3f,  -0.7f);
    glVertex2f( -0.8f,  -0.7f);
    glVertex2f(-0.7f,  -0.8f);

    glEnd();


    glBegin(GL_QUADS);//roof
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(-0.55f,-0.7f);
    glVertex2f(-0.55f,-0.65f);
    glVertex2f(-0.54f,-0.65f);
    glVertex2f(-0.54f,-0.-.7f);

    glEnd();


    glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 1.0f, 0.0f);

    glVertex2f(-0.65f,-.65f);
    glVertex2f(-0.75f,-0.5f);
    glVertex2f(-0.45f,-0.5f);
    glVertex2f(-0.4f,-.65f);

    glEnd();

  glLoadIdentity();
    glTranslatef(revpos2-0.55f,-0.81f+.6f, 0.0f);
    glColor3ub(38, 226, 255);
    glutSolidSphere(0.07,20,20);
     glLoadIdentity();
    glTranslatef(revpos2-0.65f,-0.8f+.6f, 0.0f);
    glColor3ub(38, 226, 255);
    glutSolidSphere(0.07,20,20);
        glLoadIdentity();
    glTranslatef(revpos2-0.45f,-0.8f+.6f, 0.0f);
    glColor3ub(38, 226, 255);
    glutSolidSphere(0.07,20,20);
}




void SeaMe()
{
    glLoadIdentity();
    GLfloat r1=0.0f;
    GLfloat r2=0.0f;

    for(int j=0;j<9;j++){
            glLoadIdentity();
     glTranslatef(-1.0f,r1-=.1f, 0.0f);
    glColor3ub(8, 67, 163);
    glutSolidSphere(0.1,20,20);
    for(int i=0; i<15; i++){
     glTranslatef(.15f,0.0f, 0.0f);
    glColor3ub(8, 67, 163);
    glutSolidSphere(0.1,20,20);
    }
    glLoadIdentity();
      glTranslatef(-1.0f,r2-=0.11f, 0.0f);
    glColor3ub(38, 226, 255);
    glutSolidSphere(0.1,20,20);
    for(int i=0; i<15; i++){
     glTranslatef(.15f,0.0f, 0.0f);
    glColor3ub(38, 226, 255);
    glutSolidSphere(0.1,20,20);
    }
    }


}

void Sky()
{
glLoadIdentity();
glBegin(GL_QUADS);
glColor3ub(0, 190, 226);
glVertex2f(-1.0f,1.0f);
glVertex2f(1.0f,1.0f);
glVertex2f(1.0f,-0.1f);
glVertex2f(-1.0f,-0.1f);

  glLoadIdentity();//sun
    glTranslatef(0.0f,0.0, 0.0f);
    glColor3ub(232, 167, 102);
    glutSolidSphere(0.2,20,20);
     glLoadIdentity();
}

void Cloud()
{
    glLoadIdentity();

    glTranslatef(Cloudpos,0.55f, 0.0f);
    glColor3ub(192,192,192);
    glutSolidSphere(0.1,40,20);

    glLoadIdentity();
    glTranslatef(Cloudpos-.1,0.5f, 0.0f);
    glutSolidSphere(0.05,20,10);

    glLoadIdentity();
    glTranslatef(Cloudpos+.1,0.5f, 0.0f);
    glutSolidSphere(0.05,20,10);
}

void Cloud2()
{
    glLoadIdentity();

    glTranslatef(-Cloudpos,0.7f, 0.0f);
    glColor3ub(192,192,192);
    glutSolidSphere(0.1,40,20);

    glLoadIdentity();
    glTranslatef(-Cloudpos-.1,0.65f, 0.0f);
    glutSolidSphere(0.05,20,10);

    glLoadIdentity();
    glTranslatef(-Cloudpos+.1,0.65f, 0.0f);
    glutSolidSphere(0.05,20,10);
}


void display() {
   glClear(GL_COLOR_BUFFER_BIT);
   glLoadIdentity();
    Sky();
   SeaMe();

    glPushMatrix();

    glColor3ub(153, 0, 0);
    ShipMEL();
     ShipMER();
    Cloud();
    Cloud2();
    glPopMatrix();

   glFlush();
}


int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitWindowSize(600, 550);
   glutInitWindowPosition(50, 50);
   glutCreateWindow("Basic Animation");
   glutDisplayFunc(display);
   init();
   glutKeyboardFunc(handleKeypress);
   glutMouseFunc(handleMouse);
   glutTimerFunc(100, update, 0);
   glutMainLoop();
   return 0;
}
