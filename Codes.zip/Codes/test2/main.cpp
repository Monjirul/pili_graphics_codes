#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846
void display()
{
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);
		GLfloat x=0.0f; GLfloat y=0.0f; GLfloat radius =.1f;
	int i;
	int lineAmount = 100;
	float twicePi = 2.0f * PI;
int j=0;

double xA[8]={-.15,.2,.275,-.35,-.425,.5,.575,.65};
double yA[8]={.15,.2,-.275,-.35,.425,.5,-.575,.65};
double rA[8]={.025,.035,.045,.055,.09,.07,.06,.08};
double R[8]={216,186,0,186,186,178,18,100};
double G[8]={210,84,186,34,111,156,31,154};
double B[8]={205,0,18,0,0,123,209,186};
	//glBegin(GL_LINE_LOOP);
	for(j=0;j<9;j++)
    {
      glBegin(GL_LINE_LOOP);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
		}
		 glEnd();
    //glLoadIdentity();
		radius +=.1;
    }
    glEnd();


    radius =.1f;
    int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(237, 244, 24);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

    	for(j=0;j<8;j++)
    {
   radius =rA[j];
	x=xA[j];
	y=yA[j];

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(R[j], G[j], B[j]);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

    }

	glFlush();
}


/* Main function: GLUT runs as a console application starting at main()  */
int main(int argc, char** argv) {
	glutInit(&argc, argv);                 // Initialize GLUT
	glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
	glutInitWindowSize(320, 320);   // Set the window's initial width & height

	glutDisplayFunc(display); // Register display callback handler for window re-paint

	glutMainLoop();           // Enter the event-processing loop
	return 0;
}
