/////
//grass ta thik korsi, cloud and hill add korsi
/////

///almost done... music add korle buja jabe.. any sugg ? ~MK~
#include<cstdio>
#include <GL/gl.h>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846


GLfloat Manspeed = 0.02f;
GLfloat Birdspeed = 0.01f;
GLfloat speed = 0.02f;
GLfloat speed2 = 0.008f;

GLfloat Cloudpos = 0.1f;
GLfloat Birdpos = 0.1f;
GLfloat revpos3 = 0.0f;
GLfloat Manpos = 0.1f;

//---------------------  mk  ------------------------------
int viewS=0;
bool view=false;

int flag=0;
static int score=0;
int btn=0;
void RenderBitMap(float x, float y, void *font, char *string)
{
    char *c;
    glRasterPos2f(x,y);
    for(c=string; *c != '\0'; c++)
    {
        glutBitmapCharacter(font, *c);
    }
}

static void Timer(int value){

    if(view == false)
      {
        view = true;
      }
}

void UpdateScoreBoard()
{
    glColor3f(1.0f, 1.0f, 1.0f);
    char buf[100] = {0};
    sprintf(buf, "S C O R E : %d ",score);

    RenderBitMap(-0.15,0.75, GLUT_BITMAP_HELVETICA_18, buf);
}

void handleKeypress(unsigned char key, int x, int y) {

    btn=key-'0';
    if(btn==flag)
    {
        score++;
    }
    else{

        score--;
    }
    glutPostRedisplay();
}




void IntroScreen()
{
    glColor3f(1.0f, 0.0f, 0.0f);
    char buf[100] = {0};
    sprintf(buf, "W H A C K - A - MOLE");

    RenderBitMap(-0.2,0.9, GLUT_BITMAP_HELVETICA_18, buf);
}
void HoleNo()
{
    glColor3f(1.0f, 0.0f, 0.0f);
    char buf[100] = {0};
    sprintf(buf, "7");
    RenderBitMap(-0.475,0.175, GLUT_BITMAP_TIMES_ROMAN_24, buf);

    glColor3f(1.0f, 0.0f, 0.0f);
    buf[100] = {0};
    sprintf(buf, "8");
    RenderBitMap(-0.025,0.175, GLUT_BITMAP_TIMES_ROMAN_24, buf);

    glColor3f(1.0f, 0.0f, 0.0f);
    buf[100] = {0};
    sprintf(buf, "9");
    RenderBitMap(0.425,0.175, GLUT_BITMAP_TIMES_ROMAN_24, buf);


    ///

    glColor3f(1.0f, 0.0f, 0.0f);
    buf[100] = {0};
    sprintf(buf, "4");
    RenderBitMap(-0.475,-0.2, GLUT_BITMAP_TIMES_ROMAN_24, buf);

    glColor3f(1.0f, 0.0f, 0.0f);
    buf[100] = {0};
    sprintf(buf, "5");
    RenderBitMap(-0.025,-0.2, GLUT_BITMAP_TIMES_ROMAN_24, buf);

    glColor3f(1.0f, 0.0f, 0.0f);
    buf[100] = {0};
    sprintf(buf, "6");
    RenderBitMap(0.425,-0.2, GLUT_BITMAP_TIMES_ROMAN_24, buf);

///


    glColor3f(1.0f, 0.0f, 0.0f);
    buf[100] = {0};
    sprintf(buf, "1");
    RenderBitMap(-0.475,-0.525, GLUT_BITMAP_TIMES_ROMAN_24, buf);

    glColor3f(1.0f, 0.0f, 0.0f);
    buf[100] = {0};
    sprintf(buf, "2");
    RenderBitMap(-0.025,-0.525, GLUT_BITMAP_TIMES_ROMAN_24, buf);

    glColor3f(1.0f, 0.0f, 0.0f);
    buf[100] = {0};
    sprintf(buf, "3");
    RenderBitMap(0.425,-0.525, GLUT_BITMAP_TIMES_ROMAN_24, buf);
}

void Box() /// -------------------- Edited by khalid
{
    glLoadIdentity();
    glBegin(GL_QUADS);
        glColor3ub(99, 97, 94); ///-- shadow background
        glVertex2f(-0.4f, 0.0f);
        glVertex2f(0.4f, 0.0f);
        glColor3ub(193, 186, 178);  //
        glVertex2f(0.9f, 1.0f);
        glColor3ub(193, 186, 178);  //
        glVertex2f(-0.9f, 1.0f);

        glColor3ub(142, 85, 19); ///-- right side background
        glVertex2f(0.4f, 0.0f);
        glColor3ub(216, 147, 67); //
        glVertex2f(1.0f, 0.0f);
        glVertex2f(1.0f, 1.0f);
        glVertex2f(0.9f, 1.0f);

        glColor3ub(142, 85, 19);
        glVertex2f(-0.4f, 0.0f);  ///-- left side background
        glColor3ub(216, 147, 67); //
        glVertex2f(-1.0f, 0.0f);
        glVertex2f(-1.0f, 1.0f);
        glVertex2f(-0.9f, 1.0f);

        glColor3ub(142, 85, 19);
        glColor3ub(216, 147, 67); //
        glVertex2f(-1.0f, -1.0f);  ///-- bottom side background
        glColor3ub(216, 147, 67); //
        glVertex2f(1.0f, -1.0f);
        glVertex2f(1.0f, 0.0f);
        glVertex2f(-1.0f, 0.0f);

        glColor3ub(142, 85, 19); ///-- top side
        glVertex2f(-0.65f, 0.6f);
        glVertex2f(0.65f, 0.6f);
        glColor3ub(224, 158, 83); //
        glVertex2f(0.7f, 1.0f);
        glColor3ub(224, 158, 83); //
        glVertex2f(-0.7f, 1.0f);

        glColor3ub(247, 157, 22); ///-- middle side
        glVertex2f(-0.65f, 0.6f);
        glColor3ub(204, 119, 8); //
        glVertex2f(0.65f, 0.6f);
        glColor3ub(204, 119, 8); //
        glVertex2f(0.8f, -0.85f);
        glColor3ub(204, 119, 8); //
        glVertex2f(-0.8f, -0.85f);

        glColor3ub(247, 157, 22); ///-- bottom side
        glVertex2f(-0.7f, -1.0f);
        glColor3ub(204, 119, 8); //
        glVertex2f(0.7f, -1.0f);
        glColor3ub(204, 119, 8); //
        glVertex2f(0.8f, -0.85f);
        glColor3ub(204, 119, 8); //
        glVertex2f(-0.8f, -0.85f);

    glEnd();

    glLineWidth(10);
    glColor3ub(119, 118, 117);
    glBegin(GL_LINES);
        glVertex2f(0.65f, 0.61f); ///top bottom line
        glVertex2f(-0.65f, 0.61f);

        glVertex2f(0.643f, 0.61f); ///top right line
        glVertex2f(0.69f, 1.0f);

        glVertex2f(-0.643f, 0.61f); ///top left line
        glVertex2f(-0.69f, 1.0f);

         glColor3ub(209, 203, 194); //
        glVertex2f(0.65f, 0.58f); ///middle top line
        glVertex2f(-0.65f, 0.58f);

        glVertex2f(0.642f, 0.59f); ///middle right line
        glVertex2f(0.79f, -0.84f);

        glVertex2f(-0.642f, 0.59f); ///middle left line
        glVertex2f(-0.79f, -0.84f);

        glColor3ub(160, 155, 147);
        glVertex2f(0.8f, -0.85f); /// bottom top line
        glVertex2f(-0.8f, -0.85f);

        glVertex2f(0.8f, -0.85f); /// bottom right line
        glVertex2f(0.69f, -1.0f);

        glVertex2f(-0.8f, -0.85f); /// bottom left line
        glVertex2f(-0.69f, -1.0f);

    glEnd();


///---------frist row

	glLoadIdentity();  //9
    glTranslatef(.45f,0.2f, 0.0f);
    glColor3ub(95, 95, 95);
    glutSolidSphere(0.15,20,40);
    glLoadIdentity();


	glLoadIdentity();  //8
    glTranslatef(0.0f,0.2f, 0.0f);
    glColor3ub(95, 95, 95);
    glutSolidSphere(0.15,20,40);
    glLoadIdentity();


    	glLoadIdentity();  //7
    glTranslatef(-.45f,0.2f, 0.0f);
    glColor3ub(95, 95, 95);
    glutSolidSphere(0.15,20,40);
    glLoadIdentity();

///---------2nd row

    glLoadIdentity();  //6
    glTranslatef(0.45f,-0.15f, 0.0f);
    glColor3ub(95, 95, 95);
    glutSolidSphere(0.15,20,40);
    glLoadIdentity();

    glLoadIdentity();  //5
    glTranslatef(-.0f,-0.15f, 0.0f);
    glColor3ub(95, 95, 95);
    glutSolidSphere(0.15,20,40);
    glLoadIdentity();


    glLoadIdentity();  //4
    glTranslatef(-.45f,-0.15f, 0.0f);
    glColor3ub(95, 95, 95);
    glutSolidSphere(0.15,20,40);
    glLoadIdentity();

///------3rd row

    glLoadIdentity();  //3
    glTranslatef(0.45f,-0.5f, 0.0f);
    glColor3ub(95, 95, 95);
    glutSolidSphere(0.15,20,40);
    glLoadIdentity();

    glLoadIdentity();  //2
    glTranslatef(-0.0f,-0.5f, 0.0f);
    glColor3ub(95, 95, 95);
    glutSolidSphere(0.15,20,40);
    glLoadIdentity();

    	glLoadIdentity(); //1
    glTranslatef(-.45f,-0.5f, 0.0f);
    glColor3ub(95, 95, 95);
    glutSolidSphere(0.15,20,40);
    glLoadIdentity();


}

void handleMouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON)
    {
        if (state == GLUT_DOWN)
        {
         if((x>675 && x<775)&&(y>230 && y<295)&&(flag==9))
         {
           score++;

         }
         else if((x>450 && x<550)&&(y>230 && y<295)&&(flag==8))
         {
          score++;
         }
          else if((x>225 && x<325)&&(y>230 && y<295)&&(flag==7))
         {
          score++;
         }
          else if((x>675 && x<775)&&(y>350 && y<410)&&(flag==6))
         {

          score++;
         }
          else if((x>450 && x<550)&&(y>350 && y<410)&&(flag==5))
         {
             printf("%d",flag);
         score++;
         }
          else if((x>225 && x<325)&&(y>350 && y<410)&&(flag==4))
         {
          score++;
         }

          else if((x>675 && x<775)&&(y>460 && y<530)&&(flag==3))
         {

           score++;
         }
          else if((x>450 && x<550)&&(y>460 && y<530)&&(flag==2))
         {
           score++;
         }
          else if((x>225 && x<325)&&(y>460 && y<530)&&(flag==1))
         {
           score++;
         }
else{score--;}
            printf("clicked at (%d, %d)\n", x, y);
        }
    }

    glutPostRedisplay();
}


void MoleR()
{
  //  glLoadIdentity();
    //hole
    glBegin(GL_QUADS); // 9
     //glColor3ub(1, 1, 0);
    glColor3ub(114, 45, 10);
    glVertex2f(.35f,.3f);
    glVertex2f(.55f,.3f);
    glVertex2f(.55f,.1f);
    glVertex2f(.35f,.1f);
    glEnd();

//mole body
    GLfloat x=0.45f; GLfloat y=0.225f;
	int i;
	float twicePi = 2.0f * PI;
   GLfloat radius =.07f;
    int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(146, 154, 168);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();


    glBegin(GL_QUADS); // 9
     //glColor3ub(1, 1, 0);
    glColor3ub(146, 154, 168);
    glVertex2f(.38f,.12f);
    glVertex2f(.52f,.12f);
    glVertex2f(.52f,.22f);
    glVertex2f(.38f,.22f);
    glEnd();

    ////mole body end

//left eye
      x=0.42f; y=0.225f;
	 i;
	 twicePi = 2.0f * PI;
    radius =.02f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(234, 236, 239);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();
	//right eye

		  x=0.48f; y=0.225f;
	 i;
	 twicePi = 2.0f * PI;
    radius =.02f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(234, 236, 239);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();
//eye part
    glLineWidth(7.5);
    glBegin(GL_LINES);
	glColor3ub(15, 7, 3);
	glVertex2f(0.43f, 0.23f);    // x, y
	glVertex2f(0.43f, 0.215f);

	glVertex2f(0.473f, 0.23f);    // x, y
	glVertex2f(0.473f, 0.215f);
   glEnd();
//nose
  	  x=0.45f; y=0.2f;
	 i;
	 twicePi = 2.0f * PI;
    radius =.02f;
     triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(239, 87, 11);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

//teeth
    glLineWidth(5);
    glBegin(GL_LINES);
	glColor3ub(234, 236, 239);
	glVertex2f(0.442f, 0.175f);    // x, y
	glVertex2f(0.442f, 0.145f);

	glVertex2f(0.46f, 0.175f);    // x, y
	glVertex2f(0.46f, 0.145f);
   glEnd();

   glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(234, 236, 239);
	glVertex2f(0.4f, 0.175f);    // x, y
	glVertex2f(0.44f, 0.19f);


	glVertex2f(0.457f, 0.19f);
	glVertex2f(0.493f, 0.175f);    // x, y
	glEnd();

	//glLoadIdentity();
		}


void Mole()
{
   // glColor3ub(56, 41, 255);
    if(flag==9)
    {
        glLoadIdentity();
          MoleR();
        glLoadIdentity();
    }
    else if(flag==8){
        glLoadIdentity();
        glTranslatef(-0.45f,0.0f, 0.0f);
        MoleR();
        glLoadIdentity();
    }
    else if(flag==7){
            glLoadIdentity();
        glTranslatef(-0.9f,0.0f, 0.0f);
        MoleR();
        glLoadIdentity();
    }
    ///
    //2nd row
    else if(flag==6){
        glLoadIdentity();
        glTranslatef(0.0f,-0.35f, 0.0f);
        MoleR();
        glLoadIdentity();
    }
    else if(flag==5){
            glLoadIdentity();
        glTranslatef(-0.45f,-0.35f, 0.0f);
        MoleR();
        glLoadIdentity();
    }
    else if(flag==4){
        glLoadIdentity();
         glTranslatef(-0.9f,-0.35f, 0.0f);
        MoleR();
        glLoadIdentity();
    }
    else if(flag==3){
    glLoadIdentity();
        glTranslatef(0.0f,-0.7f, 0.0f);
        MoleR();
        glLoadIdentity();
    }else if(flag==2){
        glLoadIdentity();
     glTranslatef(-0.45f,-0.7f, 0.0f);
        MoleR();
        glLoadIdentity();
    }
    else if(flag==1){
        glLoadIdentity();
      glTranslatef(-0.9f,-0.7f, 0.0f);
        MoleR();
        glLoadIdentity();
    }
}

//mk end
void update(int value)  ///----------------- fixed-----
{
   if(view==false)
   {
    if(Cloudpos > 1.0)
    {
        Cloudpos = -1.5;
    }
    if(Manpos > 1)
    {
        Manspeed =0.0;
        speed2=0.0;
    }
    if(Birdpos > 1.0)
    {
        Birdpos =-1.5;
        //speed2=0.0;
    }
        //viewS++;
       // printf("%d ",viewS);

        revpos3 +=speed2;
        Cloudpos += speed;
        Manpos +=Manspeed;
        Birdpos +=Birdspeed;

        glutPostRedisplay();
        glutTimerFunc(100, update, 0);
   }
   else  /// one timer for both
   {
       glutPostRedisplay();
       glutTimerFunc(2000, update, 0);
   }

}

void init() {
   glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
}

void Head()
{
     glBegin(GL_QUADS);//roof
    glColor3ub(237, 229, 222);

    glVertex2f(0.56f,-0.26f);
    glVertex2f(0.6f,-0.26f);
    glVertex2f(0.6f,-0.2f);
    glVertex2f(0.56f,-0.2f);

    glEnd();
//cul
    glBegin(GL_QUADS);//roof
    glColor3ub(56, 54, 52);

    glVertex2f(0.56f,-0.2f);
    glVertex2f(0.6f,-0.2f);
    glVertex2f(0.6f,-0.187f);
    glVertex2f(0.55f,-0.187f);

    glEnd();

    glLineWidth(1.5);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(56, 54, 52);
	glVertex2f(0.57f, -0.21f);    // x, y
	glVertex2f(0.59f, -0.21f);    // x, y

	glEnd();

	glPointSize(3.0);
	glBegin(GL_POINTS);              // Each set of 4 vertices form a quad
	glColor3ub(56, 54, 52);
	glVertex2f(0.58f, -0.22f);    // x, y

	glEnd();

	glLineWidth(1.5);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(232, 176, 120);
	glVertex2f(0.575f, -0.24f);    // x, y
	glVertex2f(0.59f, -0.24f);    // x, y

	glEnd();

  glBegin(GL_QUADS);//roof
    glColor3ub(181, 142, 103);

    glVertex2f(0.575f,-0.276f);
    glVertex2f(0.586f,-0.276f);
    glVertex2f(0.586f,-0.26f);
    glVertex2f(0.575f,-0.26f);

    glEnd();

}

void Body()
{
    glBegin(GL_QUADS);//roof
    glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(0.556f,-0.276f);
    glVertex2f(0.603f,-0.276f);
    glVertex2f(0.603f,-0.37f);
    glVertex2f(0.556f,-0.37f);

    glEnd();
}

void Leg1()
{
    glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(0.603f,-0.37f);
    glVertex2f(0.56f,-0.37f);
     glVertex2f(0.56f,-0.42f);
    glVertex2f(0.603f,-0.42f);

    glEnd();
//baka pa
    glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 0.0f, 1.0f);

    glVertex2f(0.54f,-0.5f);
    glVertex2f(0.56f,-0.5f);
    glVertex2f(0.59f,-0.37f);
    glVertex2f(0.56f,-0.37f);

    glEnd();
////
   glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 0.0f, 1.0f);


    glVertex2f(0.54f,-0.6f);
    glVertex2f(0.56f,-0.6f);
    glVertex2f(0.56f,-0.37f);
    glVertex2f(0.55f,-0.37f);
    glEnd();

    glLineWidth(5.5);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(56, 54, 52);
	glVertex2f(0.53f, -0.61f);    // x, y
	glVertex2f(0.56f, -0.61f);    // x, y

	glEnd();
}

void Leg2()
{
    ////right pa
	glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 0.0f, 1.0f);


    glVertex2f(0.584f,-0.37f);
    glVertex2f(0.603f,-0.37f);
    glVertex2f(0.603f,-0.6f);
    glVertex2f(0.584f,-0.6f);

    glEnd();

    glLineWidth(5.5);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(56, 54, 52);
	glVertex2f(0.57f, -0.61f);    // x, y
	glVertex2f(0.603f, -0.61f);    // x, y

	glEnd();
}

void Leg()
{

    Leg1();
    Leg2();

}

void Hand()
{
   glBegin(GL_QUADS);//roof
    //glColor3f(0.0f, 1.0f, 0.0f);
    glColor3ub(232, 176, 120);
    glVertex2f(0.515f,-0.376f);
    glVertex2f(0.535f,-0.376f);
    glVertex2f(0.58f,-0.3f);
    glVertex2f(0.56f,-0.3f);

    glEnd();
}

void Rasta()
{
     glBegin(GL_POLYGON);//roof
    //glColor3f(0.0f, 1.0f, 0.0f);
    glColor3ub(232, 176, 120);
    glVertex2f(-1.0f,-0.4f);
    glVertex2f(0.55f,-1.0f);
    glVertex2f(1.0f,-1.0f);
    glVertex2f(1.0f,-0.6f);
    glVertex2f(-1.0f,0.15f);

    glEnd();
}

void Dokan_pat()
{

     glBegin(GL_QUADS);//roof
    //glColor3f(1.0f, 0.0f, 0.0f);
    glColor3ub(164, 209, 163);
    glVertex2f(-0.7f,0.07f);
    glVertex2f(-0.2f,0.07f);
    glVertex2f(-0.2f,0.7f);
    glVertex2f(-0.7f,0.7f);

    glEnd();

    glLineWidth(1.5);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(57, 89, 57);
	glVertex2f(-0.7f, 0.65f);    // x, y
	glVertex2f(-0.2f, 0.65f);    // x, y
	glVertex2f(-0.7f, 0.6f);    // x, y
	glVertex2f(-0.2f, 0.6f);    // x, y
	glVertex2f(-0.7f, 0.55f);    // x, y
	glVertex2f(-0.2f, 0.55f);    // x, y
	glVertex2f(-0.7f, 0.5f);    // x, y
	glVertex2f(-0.2f, 0.5f);    // x, y
	glVertex2f(-0.7f, 0.45f);    // x, y
	glVertex2f(-0.2f, 0.45f);    // x, y

	glVertex2f(-0.7f, 0.35f);    // x, y
	glVertex2f(-0.2f, 0.35f);    // x, y
	glVertex2f(-0.7f, 0.3f);    // x, y
	glVertex2f(-0.2f, 0.3f);    // x, y
	glVertex2f(-0.7f, 0.25f);    // x, y
	glVertex2f(-0.2f, 0.25f);    // x, y
	glVertex2f(-0.7f, 0.2f);    // x, y
	glVertex2f(-0.2f, 0.2f);    // x, y
	glEnd();

    glLineWidth(3.5);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(57, 89, 57);
	glVertex2f(-0.7f, 0.15f);    // x, y
	glVertex2f(-0.2f, 0.15f);    // x, y

    glVertex2f(-0.39f, 0.4f);    // x, y
	glVertex2f(-0.2f, 0.4f);    // x, y

	glVertex2f(-0.7f, 0.4f);    // x, y
	glVertex2f(-0.51f, 0.4f);    // x, y

    glVertex2f(-0.51f, 0.4f);    // x, y
	glVertex2f(-0.51f, 0.15f);    // x, y

	glVertex2f(-0.39f, 0.4f);    // x, y
	glVertex2f(-0.39f, 0.15f);    // x, y
	glEnd();

    glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(-0.7f,0.15f);
    glVertex2f(-0.51f,0.15f);
    glVertex2f(-0.51f,0.4f);
    glVertex2f(-0.7f,0.4f);

    glEnd();

    glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(-0.39f,0.15f);
    glVertex2f(-0.2f,0.15f);
    glVertex2f(-0.2f,0.4f);
    glVertex2f(-0.39f,0.4f);

    glEnd();
//window
     glBegin(GL_QUADS);//roof
   // glColor3f(0.0f, 1.0f, 0.0f);
    glColor3ub(147, 78, 29);
    glVertex2f(-0.5f,0.08f);
    glVertex2f(-0.4f,0.08f);
    glVertex2f(-0.4f,0.35f);
    glVertex2f(-0.5f,0.35f);

    glEnd();

       glBegin(GL_QUADS);//roof
    glColor3f(1.0f, 0.0f, 0.0f);
    //glColor3ub(147, 78, 29);
    glVertex2f(-0.5f,0.08f);
    glVertex2f(-0.47f,0.1f);
    glVertex2f(-0.47f,0.33f);
    glVertex2f(-0.5f,0.35f);

    glEnd();


       glBegin(GL_QUADS);//roof
    glColor3f(1.0f, 0.0f, 0.0f);
    //glColor3ub(147, 78, 29);
    glVertex2f(-0.4f,0.08f);
    glVertex2f(-0.43f,0.1f);
    glVertex2f(-0.43f,0.33f);
    glVertex2f(-0.4f,0.35f);

    glEnd();

    glLineWidth(7.5);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	//glColor3ub(57, 89, 57);
	 glColor3f(1.0f, 0.0f, 0.0f);
	glVertex2f(-0.43f, 0.21f);    // x, y
	glVertex2f(-0.47f, 0.21f);    // x, y
	glEnd();

//cala
glBegin(GL_POLYGON);
    //glColor3f(1.0f, 1.0f, 1.0f);
    glColor3ub(220, 229, 220);
    glVertex2f(-0.71f, 0.42f);
    glVertex2f( -0.19f, 0.42f);
    glVertex2f( -0.25f, 0.52f);
    glVertex2f( -0.66f, 0.52f);
     glVertex2f(-0.71f, 0.42f);
    //glVertex2f(-0.7f,  -0.8f);
    glEnd();

    glLineWidth(7.5);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	//glColor3ub(57, 89, 57);
	 glColor3f(1.0f, 0.0f, 0.0f);
	glVertex2f(-0.66f, 0.52f);    // x, y
	glVertex2f(-0.7f, 0.42f);    // x, y
	glVertex2f(-0.61f, 0.52f);    // x, y
	glVertex2f(-0.66f, 0.42f);    // x, y

	glVertex2f(-0.56f, 0.52f);    // x, y
	glVertex2f(-0.6f, 0.42f);    // x, y
	glVertex2f(-0.5f, 0.52f);    // x, y
	glVertex2f(-0.54f, 0.42f);    // x, y

    glVertex2f(-0.45f, 0.52f);    // x, y
	glVertex2f(-0.48f, 0.42f);    // x, y

	glVertex2f(-0.43f, 0.52f);    // x, y
	glVertex2f(-0.42f, 0.42f);    // x, y

	glVertex2f(-0.39f, 0.52f);    // x, y
	glVertex2f(-0.37f, 0.42f);    // x, y

   glVertex2f(-0.35f, 0.52f);    // x, y
	glVertex2f(-0.32f, 0.42f);    // x, y

    glVertex2f(-0.3f, 0.52f);    // x, y
	glVertex2f(-0.26f, 0.42f);    // x, y

	glVertex2f(-0.25f, 0.52f);    // x, y
	glVertex2f(-0.2f, 0.42f);    // x, y

	glEnd();

}

void Grass()
{
    glBegin(GL_QUADS);//roof
   // glColor3f(0.0f, 1.0f, 0.0f);
    glColor3ub(9, 188, 15);
    glVertex2f(-1.0f,-1.0f);
    glVertex2f(1.0f,-1.0f);
    glColor3ub(9, 122, 13);
    glVertex2f(1.0f,0.4f);
    glVertex2f(-1.0f,0.4f);

    glEnd();
}

void Sky()
{
    glBegin(GL_QUADS);
    glColor3ub(51,255,255);
    glVertex2f(1.0f,0.4f);
    glVertex2f(-1.0f,0.4f);
    glColor3ub(51,153,255);
    glVertex2f(-1.0f,1.0f);
    glVertex2f(1.0f,1.0f);
    glEnd();
}

void Hill()
{

    float x=1.0f;

    glBegin(GL_TRIANGLES);
    glColor3ub(102,51,0);
    glVertex2f(0.2f,0.4f);
    glColor3ub(204,102,0);
    glVertex2f(0.1f, 0.5f);
    glColor3ub(153,76,0);
    glVertex2f(0.0f, 0.4f);
    glEnd();

    glBegin(GL_TRIANGLES);
    for(int i=0; i<10; i++)
    {
        glColor3ub(102,51,0);
        glVertex2f(x,0.4f);
        x=x-.1;
        glColor3ub(204,102,0);
        glVertex2f(x, 0.5f);
        x=x-.1;
        glColor3ub(153,76,0);
        glVertex2f(x, 0.4f);

        x=x-.1;
    }
    glEnd();




    glBegin(GL_TRIANGLES);
    glColor3ub(102,51,0);
    glVertex2f(0.6f,0.4f);
    glColor3ub(204,102,0);
    glVertex2f(0.5f, 0.5f);
    glColor3ub(153,76,0);
    glVertex2f(0.3f, 0.4f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(102,51,0);
    glVertex2f(-0.6f,0.4f);
    glColor3ub(204,102,0);
    glVertex2f(-0.75f, 0.5f);
    glColor3ub(153,76,0);
    glVertex2f(-1.0f, 0.4f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glVertex2f(0.4f,0.4f);
    glVertex2f(0.3f, 0.5f);
    glVertex2f(0.2f, 0.4f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(102,51,0);
    glVertex2f(0.0f,0.4f);
    glColor3ub(204,102,0);
    glVertex2f(-0.2f, 0.5f);
    glColor3ub(153,76,0);
    glVertex2f(-0.3f, 0.4f);
    glEnd();

//    glBegin(GL_TRIANGLES);
//    glVertex2f(0.2f,0.4f);
//    glVertex2f(0.1f, 0.5f);
//    glVertex2f(0.0f, 0.4f);
//    glEnd();

}


void House()
{
    //left
   glBegin(GL_TRIANGLES);
   glColor3ub(99, 51, 32);
   glVertex2f(-0.7f,-0.89f);
   glVertex2f(-0.59f,-0.89f);
    glVertex2f(-0.64f,-0.79f);
    glEnd();

     glBegin(GL_QUADS);//roof
    //glColor3f(1.0f, 0.0f, 0.0f);
    glColor3ub(234, 131, 21);
    glVertex2f(-0.7f,-0.89f);
    glVertex2f(-0.59f,-0.89f);
    glVertex2f(-0.59f,-1.0f);
   glVertex2f(-0.7f,-1.0f);
   glEnd();
   //window

    glBegin(GL_QUADS);//roof
    glColor3f(1.0f, 0.0f, 0.0f);
    //glColor3ub(234, 131, 21);
    glVertex2f(-0.68f,-0.92f);
    glVertex2f(-0.62f,-0.92f);
    glVertex2f(-0.62f,-0.98f);
   glVertex2f(-0.68f,-0.98f);
   glEnd();



   //right
     glBegin(GL_QUADS);//roof
    //glColor3f(0.0f, 0.0f, 0.0f);
    glColor3ub(229, 215, 84);
    glVertex2f(-0.59f,-1.0f);
    glVertex2f(-0.39f,-0.97f);
    glVertex2f(-0.39f,-0.86f);
   glVertex2f(-0.59f,-0.89f);
   glEnd();

   //window
   //left
     glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 0.0f, 0.0f);
    //glColor3ub(229, 215, 84);
    glVertex2f(-0.57f,-0.98f);
    glVertex2f(-0.53f,-0.976f);
    glVertex2f(-0.53f,-0.92f);
   glVertex2f(-0.57f,-0.92f);
   glEnd();

      //window
   //right
     glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 0.0f, 0.0f);
    //glColor3ub(229, 215, 84);
    glVertex2f(-0.45f,-0.96f);
    glVertex2f(-0.41f,-0.955f);
    glVertex2f(-0.41f,-0.9f);
   glVertex2f(-0.45f,-0.9f);
   glEnd();

      //window
   //right
     glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 0.0f, 0.0f);
    //glColor3ub(229, 215, 84);
    glVertex2f(-0.51f,-0.99f);
    glVertex2f(-0.47f,-0.985f);
    glVertex2f(-0.47f,-0.9f);
   glVertex2f(-0.51f,-0.9f);
   glEnd();


    glBegin(GL_QUADS);//roof
    //glColor3f(0.0f, 0.0f, 1.0f);
    glColor3ub(175, 58, 19);
    glVertex2f(-0.59f,-0.89f);
    glVertex2f(-0.39f,-0.86f);
    glVertex2f(-0.43f,-0.77f);
   glVertex2f(-0.64f,-0.79f);
   glEnd();
}

void Big_tree()
{
    glBegin(GL_QUADS);//roof
    glColor3ub(181, 71, 25);

    glVertex2f(0.8f,-0.2f);
    glVertex2f(0.88f,-0.2f);
    glVertex2f(0.88f,0.25f);
    glVertex2f(0.8f,0.25f);
    glEnd();

     glLineWidth(7.5);
    glBegin(GL_LINES);
	glColor3ub(181, 71, 25);
	//
	glVertex2f(0.81f, 0.02f);    // x, y
	glVertex2f(0.76f, 0.15f);    // x, y

	glVertex2f(0.83f, 0.25f);    // x, y
	glVertex2f(0.79f, 0.48f);    // x, y

	glVertex2f(0.825f, 0.19f);    // x, y
	glVertex2f(0.835f, 0.53f);    // x, y
	glEnd();
//left
	glBegin(GL_QUADS);//roof
    glColor3ub(181, 71, 25);
    glVertex2f(0.8f,0.25f);
    glVertex2f(0.85f,0.25f);
    glVertex2f(0.84f,0.38f);
    glVertex2f(0.805f,0.38f);
//right
    glVertex2f(0.839f,0.2f);
    glVertex2f(0.88f,0.2f);
    glVertex2f(0.89f,0.42f);
    glVertex2f(0.875f,0.42f);

    glEnd();


//coto dal pata
        GLfloat x=0.745f; GLfloat y=0.15f;
	int i;
	float twicePi = 2.0f * PI;
   GLfloat radius =.05f;
    int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(67, 191, 21);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();
		/////first layer 2
         x=0.68f;  y=0.8f;
	       radius =.113f;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(69, 183, 25);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
     glEnd();
 /////first layer 1
      x=0.55f;  y=0.76f;
	       radius =.113f;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(69, 183, 25);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
     glEnd();
/////first layer 3
     x=0.89f;  y=0.8f;
	       radius =.113f;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(59, 186, 11);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
     glEnd();

     //// left_middle3
      x=0.75f;  y=0.7f;
	       radius =.113f;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(62, 175, 19);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
     glEnd();

     ////left_middle2
      x=0.62f;  y=0.63f;
	       radius =.113f;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(62, 175, 19);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
     glEnd();

     //left_middle 4
		   x=0.93f;  y=0.67f;
	       radius =.08f;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(62, 175, 19);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
     glEnd();


     //left_middle1
           x=0.55f;  y=0.57f;
	       radius =.113f;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(62, 175, 19);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
     glEnd();


		//left1

		    x=0.73f;  y=0.55f;
	       radius =.1f;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(69, 168, 30);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();
		////left2
		    x=0.65f;  y=0.47f;
	       radius =.1f;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(69, 168, 30);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();
//left 3
		    x=0.85f;  y=0.58f;
	       radius =.1f;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(69, 168, 30);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
     glEnd();
    //left  4
         x=0.95f;  y=0.48f;
	       radius =.1f;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(69, 168, 30);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
     glEnd();


}
void Tree()
{
   glBegin(GL_TRIANGLES);

    glColor3ub(22, 71, 23);
   glVertex2f(-0.915f,-0.8f);
   glVertex2f(-0.785f,-0.8f);
    glVertex2f(-0.85f,-0.7f);
    glEnd();

    glBegin(GL_QUADS);//roof
    //glColor3f(1.0f, 0.0f, 0.0f);
    glColor3ub(181, 71, 25);
    glVertex2f(-0.875f,-0.9f);
    glVertex2f(-0.835f,-0.9f);
    glVertex2f(-0.835f,-0.8f);
    glVertex2f(-0.875f,-0.8f);

    glEnd();
    glLoadIdentity();
    glTranslatef(0.0f,0.06f,0.0f);
 glBegin(GL_TRIANGLES);

    glColor3ub(22, 71, 23);
   glVertex2f(-0.91f,-0.8f);
   glVertex2f(-0.79f,-0.8f);
    glVertex2f(-0.85f,-0.7f);
    glEnd();

    glLoadIdentity();
    glTranslatef(0.0f,0.11f,0.0f);
 glBegin(GL_TRIANGLES);

    glColor3ub(22, 71, 23);
   glVertex2f(-0.9f,-0.8f);
   glVertex2f(-0.8f,-0.8f);
    glVertex2f(-0.85f,-0.7f);
    glEnd();
}
void ManMove()
{

    glLoadIdentity();
    glTranslatef(-Manpos,revpos3, 0.0f);
    Body();
    Head();
    Hand();
    Leg();
    glLoadIdentity();
}


void Cloud()
{
    glLoadIdentity();

    glTranslatef(Cloudpos,0.9f, 0.0f);
    glColor3ub(192,192,192);
    glutSolidSphere(0.1,40,20);//wheel 1

    glLoadIdentity();
    glTranslatef(Cloudpos-.1,0.85f, 0.0f);
    glutSolidSphere(0.05,20,10);//wheel 2

    glLoadIdentity();
    glTranslatef(Cloudpos+.1,0.85f, 0.0f);
    glutSolidSphere(0.05,20,10);//wheel 2

    glLoadIdentity();
}

void Cloud2()
{
    glLoadIdentity();

    glTranslatef(-Cloudpos,0.7f, 0.0f);
    glColor3ub(192,192,192);
    glutSolidSphere(0.1,40,20);//wheel 1

    glLoadIdentity();
    glTranslatef(-Cloudpos-.1,0.65f, 0.0f);
    glutSolidSphere(0.05,20,10);//wheel 2

    glLoadIdentity();
    glTranslatef(-Cloudpos+.1,0.65f, 0.0f);
    glutSolidSphere(0.05,20,10);//wheel 2

    glLoadIdentity();
}

void Bird()
{
    glBegin(GL_QUADS);
    glColor3f(0,0,0);
    glVertex2f(-0.08f, 0.78f);
    glVertex2f(-0.05f, 0.71f);
    glVertex2f(0.03f, 0.82f);
    glVertex2f(-0.05f, 0.73f);
    glEnd();

    glBegin(GL_QUADS);
    //glColor3f(1,1,1);
    glVertex2f(-0.1f, 0.78f);
    glVertex2f(-0.07f, 0.73f);
    glVertex2f(0.01f, 0.84f);
    glVertex2f(-0.07f, 0.75f);
    glEnd();

    glBegin(GL_QUADS);
    //glColor3f(1,1,1);
    glVertex2f(-0.2f, 0.78f);
    glVertex2f(-0.17f, 0.73f);
    glVertex2f(-0.11f, 0.84f);
    glVertex2f(-0.17f, 0.75f);
    glEnd();

}

void Birds()
{
    glLoadIdentity();
    glTranslatef(Birdpos,0.8f, 0.0f);
    Bird();
    glLoadIdentity();
}


void game()
{
    glLoadIdentity();
    flag = rand() % 9 + 1;
    Box();
    IntroScreen();

    Mole();

    HoleNo();

    UpdateScoreBoard();
    glLoadIdentity();
}
void scenario()
{    Sky();
    Cloud();
    Cloud2();
     Birds();
    Hill();
    Grass();
    Rasta();
    Tree();
    House();
    Big_tree();
    Dokan_pat();


}

 void display()
 {

    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();


 if(view == false)
     {
        scenario();
        ManMove();
     }
 else if(view == true)
    {
        game();
    }
    glEnd();
    glFlush();
}



int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(1000, 660);
    glutInitWindowPosition(50, 50);
    glutCreateWindow("Basic Animation");
    glutDisplayFunc(display);
    init();

glutTimerFunc(100, update, 0); ///--- for both animation ---
glutTimerFunc(5000, Timer, 0);  /// used for making (view = true) after 5 sec

glutKeyboardFunc(handleKeypress);
glutMouseFunc(handleMouse);
    glutMainLoop();
    return 0;
}
