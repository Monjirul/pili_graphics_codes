#include<cstdio>

#include <GL/gl.h>
//#include <GL/glut.h>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846

GLfloat Cloudpos = 0.1f;
GLfloat position = 0.0f;
GLfloat speed = 0.1f;
GLfloat Pos2 = 0.0f;

void update(int value) {

    if(position < -1.0)
        position = 1.2f;

        if(Pos2 > 1.0)
        Pos2 = -1.2f;

    if(Cloudpos > 1.0)
        Cloudpos = -1.2f;

    Pos2+=speed;
    position -= speed;
    Cloudpos += speed;
	glutPostRedisplay();

     glutTimerFunc(100, update, 0);
}
void init() {
   glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}

void handleMouse(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON)
	{
		if (state == GLUT_DOWN)
		{
			speed += 0.1f;
			printf("clicked at (%d, %d)\n", x, y);
		}
	}

	glutPostRedisplay();
}

void handleKeypress(unsigned char key, int x, int y) {

	switch (key) {

case 'a':
    speed = 0.0f;
    break;
case 'w':
    speed = 0.1f;
    break;


glutPostRedisplay();

   }
}

void Cloud()
{
    glLoadIdentity();

    glTranslatef(Cloudpos,0.55f, 0.0f);
    glColor3ub(192,192,192);
    glutSolidSphere(0.1,40,20);

    glLoadIdentity();
    glTranslatef(Cloudpos-.1,0.55f, 0.0f);
    glutSolidSphere(0.1,20,10);

    glLoadIdentity();
    glTranslatef(Cloudpos+.1,0.55f, 0.0f);
    glutSolidSphere(0.1,20,10);


    glLoadIdentity();
    glTranslatef(Cloudpos+0.05,0.6f, 0.0f);
    glutSolidSphere(0.1,20,10);

     glLoadIdentity();
    glTranslatef(Cloudpos-0.05,0.5f, 0.0f);
    glutSolidSphere(0.1,20,10);
}

void Cloud2()
{
      glLoadIdentity();

    glTranslatef(Cloudpos+.9,0.55f, 0.0f);
    glColor3ub(192,192,192);
    glutSolidSphere(0.1,40,20);

    glLoadIdentity();
    glTranslatef(Cloudpos-.1+.9,0.55f, 0.0f);
    glutSolidSphere(0.1,20,10);

    glLoadIdentity();
    glTranslatef(Cloudpos+.1+.9,0.55f, 0.0f);
    glutSolidSphere(0.1,20,10);


    glLoadIdentity();
    glTranslatef(Cloudpos+0.05+.9,0.6f, 0.0f);
    glutSolidSphere(0.1,20,10);

     glLoadIdentity();
    glTranslatef(Cloudpos-0.05+.9,0.5f, 0.0f);
    glutSolidSphere(0.1,20,10);
}

void Flower()
{
    glLoadIdentity();
    glColor3ub(244, 80, 66);
    glTranslatef(.4f,-.6f, 0.0f);
    glutSolidSphere(0.1,20,10);

    glLoadIdentity();
    glColor3ub(244, 241, 65);
    glTranslatef(.4f,-.6f, 0.0f);
    glutSolidSphere(0.06,20,10);

    glLoadIdentity(); // up
    glColor3ub(244, 65, 241);
    glTranslatef(.4f,-.5f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();   //down
    glColor3ub(244, 65, 241);
    glTranslatef(.4f,-.7f, 0.0f);
    glutSolidSphere(0.02,20,10);


    glLoadIdentity();    // left
    glColor3ub(244, 65, 241);
    glTranslatef(.3f,-.6f, 0.0f);
    glutSolidSphere(0.02,20,10);


     glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.5f,-.6f, 0.0f);
    glutSolidSphere(0.02,20,10);


    ///upright
    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.49f,-.55f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.45f,-.51f, 0.0f);
    glutSolidSphere(0.02,20,10);
    ///up left
        glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.31f,-.55f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.35f,-.51f, 0.0f);
    glutSolidSphere(0.02,20,10);

    ///down left

           glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.31f,-.65f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.35f,-.69f, 0.0f);
    glutSolidSphere(0.02,20,10);


    ///down right
    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.49f,-.65f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.45f,-.69f, 0.0f);
    glutSolidSphere(0.02,20,10);
}

void Flower2()
{
   glLoadIdentity();
    glColor3ub(244, 80, 66);
    glTranslatef(-.4f,-.6f, 0.0f);
    glutSolidSphere(0.1,20,10);

    glLoadIdentity();
    glColor3ub(244, 241, 65);
    glTranslatef(-.4f,-.6f, 0.0f);
    glutSolidSphere(0.06,20,10);

    glLoadIdentity(); // up
    glColor3ub(244, 65, 241);
    glTranslatef(-.4f,-.5f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();   //down
    glColor3ub(244, 65, 241);
    glTranslatef(-.4f,-.7f, 0.0f);
    glutSolidSphere(0.02,20,10);


    glLoadIdentity();    // left
    glColor3ub(244, 65, 241);
    glTranslatef(-.3f,-.6f, 0.0f);
    glutSolidSphere(0.02,20,10);


     glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.5f,-.6f, 0.0f);
    glutSolidSphere(0.02,20,10);


    ///upright
    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.49f,-.55f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.45f,-.51f, 0.0f);
    glutSolidSphere(0.02,20,10);
    ///up left
        glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.31f,-.55f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.35f,-.51f, 0.0f);
    glutSolidSphere(0.02,20,10);

    ///down left

           glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.31f,-.65f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.35f,-.69f, 0.0f);
    glutSolidSphere(0.02,20,10);


    ///down right
    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.49f,-.65f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.45f,-.69f, 0.0f);
    glutSolidSphere(0.02,20,10);

}


void Flower3()
{
     glLoadIdentity();
    glColor3ub(244, 80, 66);
    glTranslatef(-.15f,-.6f, 0.0f);
    glutSolidSphere(0.1,20,10);

    glLoadIdentity();
    glColor3ub(244, 241, 65);
    glTranslatef(-.15f,-.6f, 0.0f);
    glutSolidSphere(0.06,20,10);

    glLoadIdentity(); // up
    glColor3ub(244, 65, 241);
    glTranslatef(-.15f,-.5f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();   //down
    glColor3ub(244, 65, 241);
    glTranslatef(-.15f,-.7f, 0.0f);
    glutSolidSphere(0.02,20,10);


    glLoadIdentity();    // left
    glColor3ub(244, 65, 241);
    glTranslatef(-.05f,-.6f, 0.0f);
    glutSolidSphere(0.02,20,10);


     glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-0.25f,-.6f, 0.0f);
    glutSolidSphere(0.02,20,10);


    ///upright
    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.24f,-.55f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.2f,-.51f, 0.0f);
    glutSolidSphere(0.02,20,10);
    ///up left
        glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.06f,-.55f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.1f,-.51f, 0.0f);
    glutSolidSphere(0.02,20,10);

    ///down left

           glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.06f,-.65f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.1f,-.69f, 0.0f);
    glutSolidSphere(0.02,20,10);


    ///down right
    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.23f,-.65f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(-.2f,-.69f, 0.0f);
    glutSolidSphere(0.02,20,10);
}


void Flower4()
{
    glLoadIdentity();
    glColor3ub(244, 80, 66);
    glTranslatef(.15f,-.6f, 0.0f);
    glutSolidSphere(0.1,20,10);

    glLoadIdentity();
    glColor3ub(244, 241, 65);
    glTranslatef(.15f,-.6f, 0.0f);
    glutSolidSphere(0.06,20,10);

    glLoadIdentity(); // up
    glColor3ub(244, 65, 241);
    glTranslatef(.15f,-.5f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();   //down
    glColor3ub(244, 65, 241);
    glTranslatef(.15f,-.7f, 0.0f);
    glutSolidSphere(0.02,20,10);


    glLoadIdentity();    // left
    glColor3ub(244, 65, 241);
    glTranslatef(.05f,-.6f, 0.0f);
    glutSolidSphere(0.02,20,10);


     glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(0.25f,-.6f, 0.0f);
    glutSolidSphere(0.02,20,10);


    ///upright
    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.24f,-.55f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.2f,-.51f, 0.0f);
    glutSolidSphere(0.02,20,10);
    ///up left
        glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.06f,-.55f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.1f,-.51f, 0.0f);
    glutSolidSphere(0.02,20,10);

    ///down left

           glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.06f,-.65f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.1f,-.69f, 0.0f);
    glutSolidSphere(0.02,20,10);


    ///down right
    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.23f,-.65f, 0.0f);
    glutSolidSphere(0.02,20,10);

    glLoadIdentity();     //right
    glColor3ub(244, 65, 241);
    glTranslatef(.2f,-.69f, 0.0f);
    glutSolidSphere(0.02,20,10);
}

void Head()
{
     glBegin(GL_QUADS);//roof
    glColor3ub(229, 166, 48);

    glVertex2f(0.56f,-0.26f);
    glVertex2f(0.6f,-0.26f);
    glVertex2f(0.6f,-0.2f);
    glVertex2f(0.56f,-0.2f);

    glEnd();
//cul
    glBegin(GL_QUADS);//roof
    glColor3ub(56, 54, 52);

    glVertex2f(0.56f,-0.2f);
    glVertex2f(0.6f,-0.2f);
    glVertex2f(0.6f,-0.187f);
    glVertex2f(0.55f,-0.187f);

    glEnd();

    glLineWidth(1.5);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(56, 54, 52);
	glVertex2f(0.57f, -0.21f);    // x, y
	glVertex2f(0.59f, -0.21f);    // x, y

	glEnd();

	glPointSize(3.0);
	glBegin(GL_POINTS);              // Each set of 4 vertices form a quad
	glColor3ub(56, 54, 52);
	glVertex2f(0.58f, -0.22f);    // x, y

	glEnd();

	glLineWidth(1.5);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(232, 176, 120);
	glVertex2f(0.575f, -0.24f);    // x, y
	glVertex2f(0.59f, -0.24f);    // x, y

	glEnd();

  glBegin(GL_QUADS);//roof
    glColor3ub(181, 142, 103);

    glVertex2f(0.575f,-0.276f);
    glVertex2f(0.586f,-0.276f);
    glVertex2f(0.586f,-0.26f);
    glVertex2f(0.575f,-0.26f);

    glEnd();

}

void Body()
{
    glBegin(GL_QUADS);//roof
    glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(0.556f,-0.276f);
    glVertex2f(0.603f,-0.276f);
    glVertex2f(0.603f,-0.37f);
    glVertex2f(0.556f,-0.37f);

    glEnd();
}

void Leg()
{
  glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(0.603f,-0.37f);
    glVertex2f(0.56f,-0.37f);
     glVertex2f(0.56f,-0.42f);
    glVertex2f(0.603f,-0.42f);

    glEnd();
//baka pa
    glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 0.0f, 1.0f);

    glVertex2f(0.54f,-0.5f);
    glVertex2f(0.56f,-0.5f);
    glVertex2f(0.59f,-0.37f);
    glVertex2f(0.56f,-0.37f);

    glEnd();
////
   glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 0.0f, 1.0f);


    glVertex2f(0.54f,-0.6f);
    glVertex2f(0.56f,-0.6f);
    glVertex2f(0.56f,-0.37f);
    glVertex2f(0.55f,-0.37f);
    glEnd();

    glLineWidth(5.5);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(232, 176, 120);
	glVertex2f(0.53f, -0.61f);    // x, y
	glVertex2f(0.56f, -0.61f);    // x, y

	glEnd();
////right pa
	glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 0.0f, 1.0f);


    glVertex2f(0.584f,-0.37f);
    glVertex2f(0.603f,-0.37f);
    glVertex2f(0.603f,-0.6f);
    glVertex2f(0.584f,-0.6f);

    glEnd();

    glLineWidth(5.5);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(232, 176, 120);
	glVertex2f(0.57f, -0.61f);    // x, y
	glVertex2f(0.603f, -0.61f);    // x, y

	glEnd();
}

void Hand()
{
   glBegin(GL_QUADS);//roof
    //glColor3f(0.0f, 1.0f, 0.0f);
   glColor3ub(232, 176, 120);
    glVertex2f(0.515f,-0.376f);
    glVertex2f(0.535f,-0.376f);
    glVertex2f(0.58f,-0.3f);
    glVertex2f(0.56f,-0.3f);



    glEnd();
}

void display() {
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
   glClear(GL_COLOR_BUFFER_BIT);




    glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
	//glColor3f(1.0f, 0.0f, 0.0f); // Red
	glColor3ub(14, 145, 206);
	glVertex2f(-1.0f, -0.4f);    // x, y
	glVertex2f(1.0f, -0.4f);    // x, y
	glVertex2f(1.0f, 1.0f);    // x, y
	glVertex2f(-1.0f, 1.0f);    // x, y

	glEnd();

glLoadIdentity();
glPushMatrix();
   Cloud();
Cloud2();
 glPopMatrix();
 glPushMatrix();
   GLfloat x=0.0f; GLfloat y=0.4f; GLfloat radius =.05f;
	int i;
	float twicePi = 2.0f * PI;
    radius =.25f;
    int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(32, 63, 178);
    	glColor3f(1.0f, 0.0f, 0.0f); // Red
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

   glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(1.0f, 1.0f, 1.0f); // Red
	glVertex2f(-1.0f, -0.4f);    // x, y
	glVertex2f(1.0f, -0.4f);    // x, y

	glEnd();

	glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	//glColor3f(1.0f, 0.0f, 0.0f); // Red
	glColor3ub(232, 235, 239);
	glVertex2f(-0.15f, -0.4f);    // x, y
	glVertex2f(-0.15f, 0.6f);    // x, y
    glEnd();

    glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	//glColor3f(1.0f, 0.0f, 0.0f); // Red
	glColor3ub(232, 235, 239);
	glVertex2f(0.15f, -0.4f);    // x, y
	glVertex2f(0.15f, 0.6f);    // x, y
    glEnd();

    glLineWidth(2.2);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 0.0f, 0.0f); // Red
	glVertex2f(-0.1f, -0.4f);    // x, y
	glVertex2f(-0.1f, 0.6f);    // x, y
	glVertex2f(-0.1f, 0.6f);    // x, y
	glVertex2f(-0.2f, 0.9f);    // x, y
	glVertex2f(-0.05f, 0.6f);    // x, y
	glVertex2f(-0.15f, 0.9f);    // x, y
	glVertex2f(-0.05f, -0.4f);    // x, y
	glVertex2f(-0.05f, 0.6f);    // x, y
	glVertex2f(-0.0f, -0.4f);    // x, y
	glVertex2f(-0.0f, 0.6f);    // x, y
	glVertex2f(0.1f, -0.4f);    // x, y
	glVertex2f(0.1f, 0.6f);    // x, y
	glVertex2f(0.05f, -0.4f);    // x, y
	glVertex2f(0.05f, 0.6f);    // x, y
	glVertex2f(0.05f, 0.6f);    // x, y
	glVertex2f(0.15f, 0.9f);    // x, y
	glVertex2f(0.1f, 0.6f);    // x, y
	glVertex2f(0.2f, 0.9f);    // x, y

    glEnd();


    glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(1.0f, 0.0f, 0.0f); // Red
	glColor3ub(232, 235, 239);
	//glVertex2f(-0.15f, 0.6f);    // x, y
	//glVertex2f(0.15f, 0.6f);    // x, y
	glVertex2f(-0.15f, 0.6f);    // x, y
	glVertex2f(-0.25f, 0.9f);    // x, y
	glVertex2f(0.15f, 0.6f);    // x, y
	glVertex2f(0.25f, 0.9f);    // x, y
	glVertex2f(-0.25f, 0.89f);    // x, y
	glVertex2f(0.25f, 0.89f);    // x, y
	glVertex2f(-0.00f, -0.4f);    // x, y
	glVertex2f(-0.00f, 0.9f);    // x, y

    glEnd();


  //left

  glLineWidth(2.2);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 0.0f, 0.0f); // Red
	glVertex2f(-0.45f, -0.4f);    // x, y
	glVertex2f(-0.45f, 0.55f);    // x, y
	glVertex2f(-0.4f, -0.4f);    // x, y
	glVertex2f(-0.4f, 0.55f);    // x, y
	glVertex2f(-0.35f, -0.4f);    // x, y
	glVertex2f(-0.35f, 0.55f);    // x, y

	glEnd();

	glLineWidth(2.2);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 0.0f, 0.0f); // Red
	glVertex2f(-0.75f, -0.4f);    // x, y
	glVertex2f(-0.75f, 0.4f);    // x, y
	glVertex2f(-0.7f, -0.4f);    // x, y
	glVertex2f(-0.7f, 0.4f);    // x, y
	glVertex2f(-0.65f, -0.4f);    // x, y
	glVertex2f(-0.65f, 0.4f);    // x, y

	glEnd();

    glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(232, 235, 239);
	glVertex2f(-0.5f, -0.4f);    // x, y
	glVertex2f(-0.5f, 0.55f);    // x, y
	glVertex2f(-0.3f, -0.4f);    // x, y
	glVertex2f(-0.3f, 0.55f);    // x, y
	glVertex2f(-0.51f, 0.55f);    // x, y
	glVertex2f(-0.293f, 0.55f);    // x, y

    glEnd();

      glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(232, 235, 239);
	glVertex2f(-0.8f, -0.4f);    // x, y
	glVertex2f(-0.8f, 0.4f);    // x, y
	glVertex2f(-0.6f, -0.4f);    // x, y
	glVertex2f(-0.6f, 0.4f);    // x, y
	glVertex2f(-0.81f, 0.4f);    // x, y
	glVertex2f(-0.593f, 0.4f);    // x, y
    glEnd();

     //right
    glLineWidth(2.2);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 0.0f, 0.0f); // Red
	glVertex2f(0.45f, -0.4f);    // x, y
	glVertex2f(0.45f, 0.55f);    // x, y
	glVertex2f(0.4f, -0.4f);    // x, y
	glVertex2f(0.4f, 0.55f);    // x, y
	glVertex2f(0.35f, -0.4f);    // x, y
	glVertex2f(0.35f, 0.55f);    // x, y

	glEnd();

	glLineWidth(2.2);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 0.0f, 0.0f); // Red
	glVertex2f(0.75f, -0.4f);    // x, y
	glVertex2f(0.75f, 0.4f);    // x, y
	glVertex2f(0.7f, -0.4f);    // x, y
	glVertex2f(0.7f, 0.4f);    // x, y
	glVertex2f(0.65f, -0.4f);    // x, y
	glVertex2f(0.65f, 0.4f);    // x, y

	glEnd();

    glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
glColor3ub(232, 235, 239);
	glVertex2f(0.5f, -0.4f);    // x, y
	glVertex2f(0.5f, 0.55f);    // x, y
	glVertex2f(0.3f, -0.4f);    // x, y
	glVertex2f(0.3f, 0.55f);    // x, y
	glVertex2f(0.51f, 0.55f);    // x, y
	glVertex2f(0.29f, 0.55f);    // x, y

    glEnd();

      glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(232, 235, 239);
	glVertex2f(0.8f, -0.4f);    // x, y
	glVertex2f(0.8f, 0.4f);    // x, y
	glVertex2f(0.6f, -0.4f);    // x, y
	glVertex2f(0.6f, 0.4f);    // x, y
    glVertex2f(0.81f, 0.4f);    // x, y
	glVertex2f(0.59f, 0.4f);    // x, y
    glEnd();

    glBegin(GL_QUADS);

	glColor3ub(153, 127, 102);

	glVertex2f(-1.0f, -0.4f);

	glVertex2f(1.0f, -0.4f);

	glVertex2f(1.0f, -1.0f);

    glVertex2f(-1.0f, -1.0f);

	glEnd();

    glBegin(GL_QUADS);

	glColor3ub(178, 152, 126);
    glVertex2f(-1.0f, -0.5f);
    glVertex2f(1.0f, -0.5f);
    glVertex2f(1.0f, -0.55f);
    glVertex2f(-1.0f, -0.55f);

	glEnd();

	glBegin(GL_QUADS);

	glColor3ub(178, 152, 126);
    glVertex2f(-1.0f, -0.65f);
    glVertex2f(1.0f, -0.65f);
    glVertex2f(1.0f, -0.7f);
    glVertex2f(-1.0f, -0.7f);

	glEnd();

	glBegin(GL_QUADS);

	glColor3ub(178, 152, 126);
    glVertex2f(-1.0f, -0.8f);
    glVertex2f(1.0f, -0.8f);
    glVertex2f(1.0f, -0.85f);
    glVertex2f(-1.0f, -0.85f);

	glEnd();

	glBegin(GL_QUADS);

	glColor3ub(178, 152, 126);
    glVertex2f(-1.0f, -0.95f);
    glVertex2f(1.0f, -0.95f);
    glVertex2f(1.0f, -1.0f);
    glVertex2f(-1.0f, -1.0f);

	glEnd();
glLoadIdentity();
	Flower();
   glLoadIdentity();
   Flower2();
 glLoadIdentity();
 Flower3();
  glLoadIdentity();
  Flower4();
  glLoadIdentity();
  glPopMatrix();

  	Head();
Hand();
 Body();
 Leg();
   glFlush();
}



int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitWindowSize(800, 600);
   glutInitWindowPosition(50, 50);
   glutCreateWindow("Basic Animation");
   glutDisplayFunc(display);
   init();
   glutKeyboardFunc(handleKeypress);
  glutMouseFunc(handleMouse);
  glutTimerFunc(100, update, 0);
   glutMainLoop();
   return 0;
}
