#include<iostream>
#include <windows.h>
#include <GL/glut.h>
#include<math.h>
# define PI           3.14159265358979323846
using namespace std;

GLfloat ii = 0.0f;
GLfloat im = 0.0f;
GLfloat ih = 0.0f;
void initGL()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Black and opaque
}

void Idle()
{
       ii-=0.01f;
       if(ii<=-360)
       {
           ii=0;
           im-=30.0;
       }
         if(im<=-360)
         {
             im=0;
         ih-=30;
         }
           if(ih<=-360)
           {
           ii=0;
           im=0;
           ih=0;
           }
    glutPostRedisplay();//// marks the current window as needing to be redisplayed
}

void Clock_indicators()
{
    glLoadIdentity();
        glBegin(GL_QUADS);//12 er kata
    glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(-0.09f, 0.8f);
    glVertex2f( 0.01f, 0.8f);
    glVertex2f( 0.01f, 0.7f);
    glVertex2f(-0.09f, 0.7f);
    glEnd();
    glPopMatrix();

    glLoadIdentity();


    glBegin(GL_QUADS);//6 er kata
    glColor3f(1.0f, 0.0f, 0.0f);

   glVertex2f(-0.09f, -0.8f);
    glVertex2f( 0.01f, -0.8f);
    glVertex2f( 0.01f, -0.7f);
   glVertex2f(-0.09f, -0.7f);
glEnd();
    glPopMatrix();

    glLoadIdentity();


        glBegin(GL_QUADS);//3 er kata
glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(0.8f, 0.01f);
    glVertex2f( 0.7f, 0.01f);
    glVertex2f( 0.7f, -0.01f);
    glVertex2f(0.8f, -0.01f);
glEnd();
    glPopMatrix();

    glLoadIdentity();


            glBegin(GL_QUADS);//9 er kata
glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(-0.8f, 0.01f);
    glVertex2f( -0.7f, 0.01f);
    glVertex2f( -0.7f, -0.01f);
    glVertex2f(-0.8f, -0.01f);
glEnd();
    glPopMatrix();


      glLoadIdentity();


 glBegin(GL_QUADS);//10 er kata
glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(-0.72f, 0.35f);
    glVertex2f( -0.65f, 0.325f);
    glVertex2f( -0.65f, 0.3f);
    glVertex2f(-0.725f, 0.325f);
    glEnd();
    glPopMatrix();


      glLoadIdentity();
   glBegin(GL_QUADS);//11 er kata
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(-0.45f, 0.655f);
    glVertex2f( -0.4f, .575f);
    glVertex2f( -0.425f, 0.555f);
    glVertex2f(-0.475f, 0.625f);
    glEnd();
    glPopMatrix();

          glLoadIdentity();
   glBegin(GL_QUADS);//1 er kata
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.45f, 0.655f);
    glVertex2f( 0.4f, .575f);
    glVertex2f( 0.425f, 0.555f);
    glVertex2f(0.475f, 0.625f);
    glEnd();
    glPopMatrix();

      glLoadIdentity();
     glBegin(GL_QUADS);//2 er kata
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.72f, 0.35f);
    glVertex2f( 0.65f, 0.325f);
    glVertex2f( 0.65f, 0.3f);
    glVertex2f(0.725f, 0.325f);
    glEnd();
    glPopMatrix();

       glLoadIdentity();
     glBegin(GL_QUADS);//4 er kata
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.72f, -0.35f);
    glVertex2f( 0.65f, -0.325f);
    glVertex2f( 0.65f, -0.3f);
    glVertex2f(0.725f, -0.325f);
    glEnd();
   glPopMatrix();
         glLoadIdentity();
   glBegin(GL_QUADS);//5 er kata
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.45f, -0.655f);
    glVertex2f( 0.4f, -0.575f);
    glVertex2f( 0.425f, -0.555f);
    glVertex2f(0.475f, -0.625f);
    glEnd();
    glPopMatrix();

     glLoadIdentity();
     glBegin(GL_QUADS);//4 er kata
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(-0.72f, -0.35f);
    glVertex2f( -0.65f, -0.325f);
    glVertex2f( -0.65f, -0.3f);
    glVertex2f(-0.725f, -0.325f);
    glEnd();
   glPopMatrix();

         glLoadIdentity();
   glBegin(GL_QUADS);//5 er kata
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(-0.45f, -0.655f);
    glVertex2f( -0.4f, -0.575f);
    glVertex2f( -0.425f, -0.555f);
    glVertex2f(-0.475f, -0.625f);
    glEnd();
    glPopMatrix();


}
void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

 ////////////circle part///////////////

 	glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)

	GLfloat x=0.0f; GLfloat y=0.0f; GLfloat radius =.8f;
	int i;
	int lineAmount = 100; //# of triangles used to draw circle

	//GLfloat radius = 0.8f; //radius
	 float twicePi = 2.0f * PI;



	glBegin(GL_LINE_LOOP);
	glColor3f(0.0f, 1.0f, 0.0f);
		for(i = 0; i <= lineAmount;i++) {
			glVertex2f(
			    x + (radius * cos(i *  twicePi / lineAmount)),
			    y + (radius* sin(i * twicePi / lineAmount))
			);
	//	cout<<"X :"<<x<<endl<<"Y :"<<y<<endl;
		}
	glEnd();





 /////////////////////////////////////


    glLoadIdentity();


Clock_indicators();
      glLoadIdentity();
    glPushMatrix();
    glRotatef(ii,0.0,0.0,0.1);

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f( 0.0f, 0.0f);
    glVertex2f( 0.0f, 0.6f);
    glEnd();
    glPopMatrix();
//min er kata

      glLoadIdentity();
    glPushMatrix();
    glRotatef(im,0.0,0.0,0.1);

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 1.0f);
   glVertex2f(-0.009f, 0.5f);
    glVertex2f( 0.001f, 0.5f);
    glVertex2f( 0.001f, 0.0f);
   glVertex2f(-0.009f, 0.0f);
    glEnd();
    glPopMatrix();

//hour er kata

  glLoadIdentity();
    glPushMatrix();
    glRotatef(ih,0.0,0.0,0.1);

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 1.0f);
   glVertex2f(-0.009f, 0.4f);
    glVertex2f( 0.001f, 0.4f);
    glVertex2f( 0.001f, 0.0f);
   glVertex2f(-0.009f, 0.0f);
    glEnd();
    glPopMatrix();

 //   cout<<ii<<"   "<<im<<"   "<<ih<<endl;
    glFlush();
}

int main(int argc, char** argv)
{
   // system("PAUSE");

    glutInit(&argc, argv);          // Initialize GLUT
    glutInitWindowSize(320, 320);
    glutCreateWindow("Model Transform");
    glutDisplayFunc(display);//
    initGL();
    glutIdleFunc(Idle);//glutIdleFunc sets the global idle callback to be func so a GLUT program can perform background processing tasks or continuous animation when window system events are not being received.
    glutMainLoop();
    return 0;}
