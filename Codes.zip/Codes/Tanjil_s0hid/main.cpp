#include<cstdio>

#include <GL/gl.h>
//#include <GL/glut.h>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846


void display() {
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
   glClear(GL_COLOR_BUFFER_BIT);




    glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
	//glColor3f(1.0f, 0.0f, 0.0f); // Red
	glColor3ub(14, 145, 206);
	glVertex2f(-1.0f, -0.4f);    // x, y
	glVertex2f(1.0f, -0.4f);    // x, y
	glVertex2f(1.0f, 1.0f);    // x, y
	glVertex2f(-1.0f, 1.0f);    // x, y

	glEnd();

glLoadIdentity();
glPushMatrix();

 glPopMatrix();

   GLfloat x=0.0f; GLfloat y=0.4f; GLfloat radius =.05f;
	int i;
	float twicePi = 2.0f * PI;
    radius =.25f;
    int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(32, 63, 178);
    	glColor3f(1.0f, 0.0f, 0.0f); // Red
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

   glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(1.0f, 1.0f, 1.0f); // Red
	glVertex2f(-1.0f, -0.4f);    // x, y
	glVertex2f(1.0f, -0.4f);    // x, y

	glEnd();

	glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	//glColor3f(1.0f, 0.0f, 0.0f); // Red
	glColor3ub(232, 235, 239);
	glVertex2f(-0.15f, -0.4f);    // x, y
	glVertex2f(-0.15f, 0.6f);    // x, y
    glEnd();

    glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	//glColor3f(1.0f, 0.0f, 0.0f); // Red
	glColor3ub(232, 235, 239);
	glVertex2f(0.15f, -0.4f);    // x, y
	glVertex2f(0.15f, 0.6f);    // x, y
    glEnd();

    glLineWidth(2.2);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 0.0f, 0.0f); // Red
	glVertex2f(-0.1f, -0.4f);    // x, y
	glVertex2f(-0.1f, 0.6f);    // x, y
	glVertex2f(-0.1f, 0.6f);    // x, y
	glVertex2f(-0.2f, 0.9f);    // x, y
	glVertex2f(-0.05f, 0.6f);    // x, y
	glVertex2f(-0.15f, 0.9f);    // x, y
	glVertex2f(-0.05f, -0.4f);    // x, y
	glVertex2f(-0.05f, 0.6f);    // x, y
	glVertex2f(-0.0f, -0.4f);    // x, y
	glVertex2f(-0.0f, 0.6f);    // x, y
	glVertex2f(0.1f, -0.4f);    // x, y
	glVertex2f(0.1f, 0.6f);    // x, y
	glVertex2f(0.05f, -0.4f);    // x, y
	glVertex2f(0.05f, 0.6f);    // x, y
	glVertex2f(0.05f, 0.6f);    // x, y
	glVertex2f(0.15f, 0.9f);    // x, y
	glVertex2f(0.1f, 0.6f);    // x, y
	glVertex2f(0.2f, 0.9f);    // x, y

    glEnd();


    glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(1.0f, 0.0f, 0.0f); // Red
	glColor3ub(232, 235, 239);
	//glVertex2f(-0.15f, 0.6f);    // x, y
	//glVertex2f(0.15f, 0.6f);    // x, y
	glVertex2f(-0.15f, 0.6f);    // x, y
	glVertex2f(-0.25f, 0.9f);    // x, y
	glVertex2f(0.15f, 0.6f);    // x, y
	glVertex2f(0.25f, 0.9f);    // x, y
	glVertex2f(-0.25f, 0.89f);    // x, y
	glVertex2f(0.25f, 0.89f);    // x, y
	glVertex2f(-0.00f, -0.4f);    // x, y
	glVertex2f(-0.00f, 0.9f);    // x, y

    glEnd();


  //left

  glLineWidth(2.2);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 0.0f, 0.0f); // Red
	glVertex2f(-0.45f, -0.4f);    // x, y
	glVertex2f(-0.45f, 0.55f);    // x, y
	glVertex2f(-0.4f, -0.4f);    // x, y
	glVertex2f(-0.4f, 0.55f);    // x, y
	glVertex2f(-0.35f, -0.4f);    // x, y
	glVertex2f(-0.35f, 0.55f);    // x, y

	glEnd();

	glLineWidth(2.2);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 0.0f, 0.0f); // Red
	glVertex2f(-0.75f, -0.4f);    // x, y
	glVertex2f(-0.75f, 0.4f);    // x, y
	glVertex2f(-0.7f, -0.4f);    // x, y
	glVertex2f(-0.7f, 0.4f);    // x, y
	glVertex2f(-0.65f, -0.4f);    // x, y
	glVertex2f(-0.65f, 0.4f);    // x, y

	glEnd();

    glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(232, 235, 239);
	glVertex2f(-0.5f, -0.4f);    // x, y
	glVertex2f(-0.5f, 0.55f);    // x, y
	glVertex2f(-0.3f, -0.4f);    // x, y
	glVertex2f(-0.3f, 0.55f);    // x, y
	glVertex2f(-0.51f, 0.55f);    // x, y
	glVertex2f(-0.293f, 0.55f);    // x, y

    glEnd();

      glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(232, 235, 239);
	glVertex2f(-0.8f, -0.4f);    // x, y
	glVertex2f(-0.8f, 0.4f);    // x, y
	glVertex2f(-0.6f, -0.4f);    // x, y
	glVertex2f(-0.6f, 0.4f);    // x, y
	glVertex2f(-0.81f, 0.4f);    // x, y
	glVertex2f(-0.593f, 0.4f);    // x, y
    glEnd();

     //right
    glLineWidth(2.2);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 0.0f, 0.0f); // Red
	glVertex2f(0.45f, -0.4f);    // x, y
	glVertex2f(0.45f, 0.55f);    // x, y
	glVertex2f(0.4f, -0.4f);    // x, y
	glVertex2f(0.4f, 0.55f);    // x, y
	glVertex2f(0.35f, -0.4f);    // x, y
	glVertex2f(0.35f, 0.55f);    // x, y

	glEnd();

	glLineWidth(2.2);
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 0.0f, 0.0f); // Red
	glVertex2f(0.75f, -0.4f);    // x, y
	glVertex2f(0.75f, 0.4f);    // x, y
	glVertex2f(0.7f, -0.4f);    // x, y
	glVertex2f(0.7f, 0.4f);    // x, y
	glVertex2f(0.65f, -0.4f);    // x, y
	glVertex2f(0.65f, 0.4f);    // x, y

	glEnd();

    glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
glColor3ub(232, 235, 239);
	glVertex2f(0.5f, -0.4f);    // x, y
	glVertex2f(0.5f, 0.55f);    // x, y
	glVertex2f(0.3f, -0.4f);    // x, y
	glVertex2f(0.3f, 0.55f);    // x, y
	glVertex2f(0.51f, 0.55f);    // x, y
	glVertex2f(0.29f, 0.55f);    // x, y

    glEnd();

      glLineWidth(7.5);
	glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3ub(232, 235, 239);
	glVertex2f(0.8f, -0.4f);    // x, y
	glVertex2f(0.8f, 0.4f);    // x, y
	glVertex2f(0.6f, -0.4f);    // x, y
	glVertex2f(0.6f, 0.4f);    // x, y
    glVertex2f(0.81f, 0.4f);    // x, y
	glVertex2f(0.59f, 0.4f);    // x, y
    glEnd();

    glBegin(GL_QUADS);

	glColor3ub(153, 127, 102);

	glVertex2f(-1.0f, -0.4f);

	glVertex2f(1.0f, -0.4f);

	glVertex2f(1.0f, -1.0f);

    glVertex2f(-1.0f, -1.0f);

	glEnd();

    glBegin(GL_QUADS);

	glColor3ub(178, 152, 126);
    glVertex2f(-1.0f, -0.5f);
    glVertex2f(1.0f, -0.5f);
    glVertex2f(1.0f, -0.55f);
    glVertex2f(-1.0f, -0.55f);

	glEnd();

	glBegin(GL_QUADS);

	glColor3ub(178, 152, 126);
    glVertex2f(-1.0f, -0.65f);
    glVertex2f(1.0f, -0.65f);
    glVertex2f(1.0f, -0.7f);
    glVertex2f(-1.0f, -0.7f);

	glEnd();

	glBegin(GL_QUADS);

	glColor3ub(178, 152, 126);
    glVertex2f(-1.0f, -0.8f);
    glVertex2f(1.0f, -0.8f);
    glVertex2f(1.0f, -0.85f);
    glVertex2f(-1.0f, -0.85f);

	glEnd();

	glBegin(GL_QUADS);

	glColor3ub(178, 152, 126);
    glVertex2f(-1.0f, -0.95f);
    glVertex2f(1.0f, -0.95f);
    glVertex2f(1.0f, -1.0f);
    glVertex2f(-1.0f, -1.0f);

	glEnd();

   glFlush();
}



int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitWindowSize(800, 600);
   glutInitWindowPosition(50, 50);
   glutCreateWindow("Basic Animation");
   glutDisplayFunc(display);
   //init();
   //glutKeyboardFunc(handleKeypress);
  //glutMouseFunc(handleMouse);
  //glutTimerFunc(100, update, 0);
   glutMainLoop();
   return 0;
}
