#include <windows.h>
#include <GL/glut.h>

//GLfloat i = 0.0f;
GLfloat ii = 0.0f;
GLfloat im = 0.0f;
GLfloat ih = 0.0f;

void initGL()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Black and opaque
}



void Idle()
{
       ii-=0.01f;
       if(ii<=-360)
       {
           ii=0;
           im-=30.0;
       }
         if(im<=-360)
         {
             im=0;
         ih-=30;
         }
           if(ih<=-360)
           {
           ii=0;
           im=0;
           ih=0;
           }
    glutPostRedisplay();//// marks the current window as needing to be redisplayed
}
void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();//Reset the current matrix
    glBegin(GL_QUADS);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(-0.7f, 0.7f);
    glVertex2f( 0.7f, 0.7f);
    glVertex2f( 0.7f,-0.7f);
    glVertex2f(-0.7f,-0.7f);

    glEnd();


   glPushMatrix(); //glPushMatrix copies the top matrix and pushes it onto the stack, while glPopMatrix pops the top matrix off the stack
    glRotatef(ii,0.0,0.0,0.1);//i=how many degree you want to rotate around an axis


   //sec
   glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(0.0f, 0.0f);    // x, y
	glVertex2f(0.0f, 0.5f);    // x, y
   glEnd();
   glLoadIdentity();
    glPopMatrix();

    //min
    glPushMatrix(); //glPushMatrix copies the top matrix and pushes it onto the stack, while glPopMatrix pops the top matrix off the stack
    glRotatef(im,0.0,0.0,0.1);
   glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(0.0f, 0.0f);    // x, y
	glVertex2f(0.0f, 0.55f);    // x, y
   glEnd();
   glLoadIdentity();

   //hour

     glPopMatrix();

    //min
    glPushMatrix(); //glPushMatrix copies the top matrix and pushes it onto the stack, while glPopMatrix pops the top matrix off the stack
    glRotatef(ih,0.0,0.0,0.1);
   glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(0.0f, 0.0f);    // x, y
	glVertex2f(0.0f, 0.4f);    // x, y
   glEnd();
   glLoadIdentity();
       glPopMatrix();


//3
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(0.7f, 0.0f);    // x, y
	glVertex2f(0.6f, 0.0f);    // x, y

    glEnd();
glLoadIdentity();
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(-0.7f, 0.0f);    // x, y
	glVertex2f(-0.6f, 0.0f);    // x, y

    glEnd();

   //12
    glLoadIdentity();
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(0.0f, 0.7f);    // x, y
	glVertex2f(0.0f, 0.6f);    // x, y

    glEnd();

    //6
    glLoadIdentity();
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(0.0f, -0.7f);    // x, y
	glVertex2f(0.0f, -0.6f);    // x, y

    glEnd();

//7
        glLoadIdentity();
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(-0.325f, -0.7f);    // x, y
	glVertex2f(-0.325f, -0.6f);    // x, y

    glEnd();


    //5
        glLoadIdentity();
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(0.325f, -0.7f);    // x, y
	glVertex2f(0.325f, -0.6f);    // x, y

    glEnd();



    //11
        glLoadIdentity();
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(-0.325f, 0.7f);    // x, y
	glVertex2f(-0.325f, 0.6f);    // x, y

    glEnd();


    //1
        glLoadIdentity();
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(0.325f, 0.7f);    // x, y
	glVertex2f(0.325f, 0.6f);    // x, y

    glEnd();


    glLoadIdentity();
//2
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(0.7f, 0.325f);    // x, y
	glVertex2f(0.6f, 0.325f);    // x, y
glEnd();


    glLoadIdentity();
//4
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(0.7f, -0.325f);    // x, y
	glVertex2f(0.6f, -0.325f);    // x, y
glEnd();



    glLoadIdentity();
//10
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(-0.7f, 0.325f);    // x, y
	glVertex2f(-0.6f, 0.325f);    // x, y
glEnd();


    glLoadIdentity();
//8
    glBegin(GL_LINES);              // Each set of 4 vertices form a quad
	glColor3f(0.0f, 1.0f, 0.0f); // Red
	glVertex2f(-0.7f, -0.325f);    // x, y
	glVertex2f(-0.6f, -0.325f);    // x, y
glEnd();



    glPopMatrix();


    //i-=0.67f;

    glFlush();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);          // Initialize GLUT
    glutInitWindowSize(320, 320);
    glutCreateWindow("Model Transform");
    glutDisplayFunc(display);//
    initGL();
    glutIdleFunc(Idle);//glutIdleFunc sets the global idle callback to be func so a GLUT program can perform background processing tasks or continuous animation when window system events are not being received.
    glutMainLoop();
    return 0;

}
