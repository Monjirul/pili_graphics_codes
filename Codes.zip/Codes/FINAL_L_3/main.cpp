#include<cstdio>

#include <GL/gl.h>
//#include <GL/glut.h>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846


void display() {
   glClear(GL_COLOR_BUFFER_BIT);
   glLoadIdentity();


//Road();
glPushMatrix();
//glTranslatef(position,0.0f, 0.0f);

glBegin(GL_POLYGON);

    //glColor3f(1.0f, 0.0f, 0.0f);
    glColor3ub(135, 108, 55);

    glVertex2f(-0.7f, -0.8f);
    glVertex2f( -0.4f, -0.8f);
    glVertex2f( -0.3f,  -0.7f);
    glVertex2f( -0.8f,  -0.7f);
    glVertex2f(-0.7f,  -0.8f);

    glEnd();

    glBegin(GL_QUADS);//roof
    glColor3f(1.0f, 0.0f, 0.0f);
    //glColor3ub(120, 107, 153);
    glVertex2f(-0.7f,-0.7f);

    glVertex2f(-0.4f,-0.7f);

    glVertex2f(-0.4f,-0.65f);

    glVertex2f(-0.7f,-0.65f);

    glEnd();

    glBegin(GL_QUADS);//roof
    //glColor3f(0.0f, 0.0f, 1.0f);
    glColor3ub(128, 31, 158);
    glVertex2f(-0.65f,-0.65f);
    glVertex2f(-0.45f,-0.65f);
    glVertex2f(-0.45f,-0.62f);
    glVertex2f(-0.65f,-0.62f);

    glEnd();

    glBegin(GL_QUADS);//roof
    glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(-0.55f,-0.-.62f);
    glVertex2f(-0.55f,-0.6f);
    glVertex2f(-0.54f,-0.6f);
    glVertex2f(-0.54f,-0.-.62f);

    glEnd();


    glBegin(GL_QUADS);//roof
    //glColor3f(1.0f, 0.0f, 0.0f);
    glColor3ub(214, 135, 29);
    glVertex2f(-0.6f,-0.-.6f);
    glVertex2f(-0.55f,-0.51f);
    glVertex2f(-0.45f,-0.51f);
    glVertex2f(-0.5f,-0.-.6f);

    glEnd();

    GLfloat x=0.75f; GLfloat y=0.8f; GLfloat radius =.05f;
	int i;
	float twicePi = 2.0f * PI;
    radius =.1f;
    int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(247, 243, 12);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();





    glPopMatrix();

    glFlush();
}





int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitWindowSize(800, 600);
   glutInitWindowPosition(50, 50);
   glutCreateWindow("Basic Animation");
   glutDisplayFunc(display);
   //init();
  // glutKeyboardFunc(handleKeypress);
  // glutMouseFunc(handleMouse);
//   glutTimerFunc(100, update, 0);
   glutMainLoop();
   return 0;
}
