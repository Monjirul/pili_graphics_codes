// Sample Midpoint Circle Algorithm

#include<windows.h>
#include<iostream>
#include<math.h>
#include <stdio.h>
#include<GL/gl.h>
#include <GL/glut.h>

using namespace std;

int X1, Y1, X2, Y2, r ,cx, cy;


void jaw(int x, int y)
{
	glBegin(GL_POINTS);
	x+=cx;
	y+=cy;
	glVertex2i(x, y);
	glEnd();
}

void midPointCircle(void)
{
    glClear (GL_COLOR_BUFFER_BIT);
	glColor3f (0.0, 0.0, 0.0);
	glPointSize(1.0);

	int x = 0;
	int y = r;
	float d = 1 - r;
	jaw(x, y);

	while (y > x)
	{
		if (d < 0)
		{
			x++;
			d += 2*x+3;
		}
		else
		{
			y--;
			x++;
			d += 2*(x-y)+5;
		}
		jaw(x, y);
		jaw(x, -y);
		jaw(-x, y);
		jaw(-x, -y);
		jaw(y, x);
		jaw(-y, x);
		jaw(y, -x);
		jaw(-y, -x);
	}
    glFlush ();
}


void myInit (void)
{
    glClearColor(1.0, 1.0, 1.0, 0.0);
    glColor3f(0.0f, 0.0f, 0.0f);
    glPointSize(4.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-100.0, 640.0,-100.0, 480.0);
//    gluOrtho2D(0.0, 640.0,0.0, 480.0);
}

int main(int argc, char** argv)
{


    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (640, 480);
    glutInitWindowPosition (100, 150);
    glutCreateWindow ("Midpoint Circle");

    cout<<"Enter an initial points:\t";
    cin>>cx;
    cin>>cy;
    cout<<"Enter Radius:\t";
    cin>>r;

    glutDisplayFunc(midPointCircle);
    myInit ();
    glutMainLoop();

}



