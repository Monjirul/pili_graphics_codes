#include<cstdio>

#include <GL/gl.h>
//#include <GL/glut.h>
#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>>
# define PI           3.14159265358979323846

GLfloat Cloudpos = 0.1f;
GLfloat position = 0.0f;
GLfloat speed = 0.1f;
GLfloat Pos2 = 0.0f;
void update(int value) {

    if(position < -1.0)
        position = 1.2f;

        if(Pos2 > 1.0)
        Pos2 = -1.2f;

    if(Cloudpos > 1.0)
        Cloudpos = -1.2f;

    Pos2+=speed;
    position -= speed;
    Cloudpos += speed;
	glutPostRedisplay();


	glutTimerFunc(100, update, 0);
}
void init() {
   glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}

void handleMouse(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON)
	{
		if (state == GLUT_DOWN)
		{
			speed += 0.1f;
			printf("clicked at (%d, %d)\n", x, y);
		}
	}

	glutPostRedisplay();
}

void handleKeypress(unsigned char key, int x, int y) {

	switch (key) {

case 'a':
    speed = 0.0f;
    break;
case 'w':
    speed = 0.1f;
    break;


glutPostRedisplay();


	}
}


void Ship2()
{
   // ShipSea();
glLoadIdentity();
    glPushMatrix();

glTranslatef(Pos2,0.5f,0.0f);
 glBegin(GL_POLYGON);

    glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(-0.7f, -0.8f);
    glVertex2f( -0.4f, -0.8f);
    //glVertex2f( -0.4f, -0.8f);
    glVertex2f( -0.3f,  -0.7f);
    glVertex2f( -0.8f,  -0.7f);
    glVertex2f(-0.7f,  -0.8f);

    glEnd();

    glBegin(GL_QUADS);//roof
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(-0.7f,-0.7f);

    glVertex2f(-0.4f,-0.7f);

    glVertex2f(-0.4f,-0.65f);

    glVertex2f(-0.7f,-0.65f);

    glEnd();

    glBegin(GL_QUADS);//roof
    //glColor3f(0.0f, 0.0f, 1.0f);
    glColor3ub(255, 229, 66);
    glVertex2f(-0.65f,-0.65f);
    glVertex2f(-0.45f,-0.65f);
    glVertex2f(-0.45f,-0.62f);
    glVertex2f(-0.65f,-0.62f);

    glEnd();

    glBegin(GL_QUADS);//roof
    glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(-0.55f,-0.-.62f);
    glVertex2f(-0.55f,-0.6f);
    glVertex2f(-0.54f,-0.6f);
    glVertex2f(-0.54f,-0.-.62f);

    glEnd();


    glBegin(GL_QUADS);//roof
    glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(-0.6f,-0.-.6f);
    glVertex2f(-0.55f,-0.51f);
    glVertex2f(-0.45f,-0.51f);
    glVertex2f(-0.5f,-0.-.6f);

    glEnd();


//wave1
     GLfloat x=-0.45f; GLfloat y=-0.8f;
	int i;
	float twicePi = 2.0f * PI;
   GLfloat radius =.05f;
    int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(39, 229, 239);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		  x=-0.45f;  y=-0.81f;


    radius =.05f;


    	glBegin(GL_TRIANGLE_FAN);
    	glColor3f(0.0f, 0.0f, 1.0f);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

//wave1


//wave2
      x=-0.55f;  y=-0.8f;

   radius =.05f;


    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(39, 229, 239);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		  x=-0.55f;  y=-0.81f;


    radius =.05f;


    	glBegin(GL_TRIANGLE_FAN);
    	glColor3f(0.0f, 0.0f, 1.0f);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

//wave2


//wave3
      x=-0.65f;  y=-0.8f;

   radius =.05f;


    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(39, 229, 239);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		  x=-0.65f;  y=-0.81f;


    radius =.05f;


    	glBegin(GL_TRIANGLE_FAN);
    	glColor3f(0.0f, 0.0f, 1.0f);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

//wave3

////////////////////
       x=-0.35f;  y=-0.6f;  radius =.05f;

       radius =.025f;


    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(248, 252, 32);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();


glBegin(GL_POLYGON);
    //glColor3f(1.0f, 1.0f, 0.0f);
    glColor3ub(157, 157, 170);
    glVertex2f(-0.4f, -0.7f);
    glVertex2f( -0.32f, -0.7f);
    glVertex2f( -0.35f,  -0.63f);
    //glVertex2f( -0.8f,  -0.7f);
    //glVertex2f(-0.7f,  -0.8f);
    glEnd();
}


void Cloud()
{
    glLoadIdentity();

    glTranslatef(Cloudpos,0.55f, 0.0f);
    glColor3ub(192,192,192);
    glutSolidSphere(0.1,40,20);

    glLoadIdentity();
    glTranslatef(Cloudpos-.1,0.55f, 0.0f);
    glutSolidSphere(0.1,20,10);

    glLoadIdentity();
    glTranslatef(Cloudpos+.1,0.55f, 0.0f);
    glutSolidSphere(0.1,20,10);


    glLoadIdentity();
    glTranslatef(Cloudpos+0.05,0.6f, 0.0f);
    glutSolidSphere(0.1,20,10);

     glLoadIdentity();
    glTranslatef(Cloudpos-0.05,0.5f, 0.0f);
    glutSolidSphere(0.1,20,10);
}



void Cloud2()
{
      glLoadIdentity();

    glTranslatef(Cloudpos+.9,0.55f, 0.0f);
    glColor3ub(192,192,192);
    glutSolidSphere(0.1,40,20);

    glLoadIdentity();
    glTranslatef(Cloudpos-.1+.9,0.55f, 0.0f);
    glutSolidSphere(0.1,20,10);

    glLoadIdentity();
    glTranslatef(Cloudpos+.1+.9,0.55f, 0.0f);
    glutSolidSphere(0.1,20,10);


    glLoadIdentity();
    glTranslatef(Cloudpos+0.05+.9,0.6f, 0.0f);
    glutSolidSphere(0.1,20,10);

     glLoadIdentity();
    glTranslatef(Cloudpos-0.05+.9,0.5f, 0.0f);
    glutSolidSphere(0.1,20,10);
}

/*void Sun()
{
    glLoadIdentity();
        GLfloat x=0.75f; GLfloat y=0.8f; GLfloat radius =.05f;
	int i;
	float twicePi = 2.0f * PI;
    radius =.2f;
    int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(247, 243, 12);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();
   glLoadIdentity();
}*/
void Sun2()
{
     glLoadIdentity();
    glTranslatef(.75,0.8f, 0.0f);
    glColor3ub(247, 243, 12);
    glutSolidSphere(0.2,40,20);
      glLoadIdentity();

}
void Sky()
{
glLoadIdentity();
glBegin(GL_QUADS);
glColor3ub(0, 190, 226);
glVertex2f(-1.0f,1.0f);
glVertex2f(1.0f,1.0f);
glVertex2f(1.0f,-0.1f);
glVertex2f(-1.0f,-0.1f);
//Sun
   glLoadIdentity();
       GLfloat x=0.75f; GLfloat y=0.8f; GLfloat radius =.05f;
	int i;
	float twicePi = 2.0f * PI;
    radius =.2f;
    int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(247, 243, 12);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();
   glLoadIdentity();
}
void Sea()
{

      glBegin(GL_QUADS);
      glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(-1.0f, 0.0f);
   glVertex2f(1.0f, 0.0f);
   glVertex2f(1.0f, -1.0f);
   glVertex2f(-1.0f,-1.0f);
glEnd();

GLfloat x1=-1.0f ;
GLfloat x2=-.95f;
GLfloat y=-0.0f;
for(int j=0;j<10;j++){
    glLoadIdentity();
GLfloat x1=-1.0f ;
GLfloat x2=-.95f;
glBegin(GL_LINES);

for(int i=0;i<50;i++){
  //glColor3f(1.0f, 0.0f, 0.0f);
  glColor3ub(39, 229, 239);
      glVertex2f(x1, y);
      glVertex2f(x2, y);
x1+=.08f;
x2+=.08f;
}

glEnd();
y-=.1;
}
}

void display() {
   glClear(GL_COLOR_BUFFER_BIT);
   glLoadIdentity();
Sky();
Sun2();
// SeaMe();
Sea();
glPushMatrix();
glTranslatef(position,0.0f, 0.0f);

glBegin(GL_POLYGON);
    //glColor3f(1.0f, 0.0f, 0.0f);
    glColor3ub(35, 32, 10);
    glVertex2f(-0.7f, -0.8f);
    glVertex2f( -0.4f, -0.8f);
    glVertex2f( -0.3f,  -0.7f);
    glVertex2f( -0.8f,  -0.7f);
    glVertex2f(-0.7f,  -0.8f);
    glEnd();

    glBegin(GL_QUADS);//roof
    //glColor3f(0.0f, 1.0f, 0.0f);
    glColor3ub(239, 39, 82);
    glVertex2f(-0.7f,-0.7f);

    glVertex2f(-0.4f,-0.7f);

    glVertex2f(-0.4f,-0.65f);

    glVertex2f(-0.7f,-0.65f);

    glEnd();

    glBegin(GL_QUADS);//roof
    //glColor3f(1.0f, 1.0f, 1.0f);
   glColor3ub(239, 39, 239);
    glVertex2f(-0.65f,-0.65f);
    glVertex2f(-0.45f,-0.65f);
    glVertex2f(-0.45f,-0.62f);
    glVertex2f(-0.65f,-0.62f);
    glEnd();

    glBegin(GL_QUADS);//roof
    glColor3f(1.0f, 0.0f, 0.0f);

    glVertex2f(-0.55f,-0.-.62f);
    glVertex2f(-0.55f,-0.6f);
    glVertex2f(-0.54f,-0.6f);
    glVertex2f(-0.54f,-0.-.62f);
    glEnd();


    glBegin(GL_QUADS);//roof
    //glColor3f(1.0f, 0.0f, 0.0f);
    glColor3ub(255, 229, 66);
    glVertex2f(-0.6f,-0.-.6f);
    glVertex2f(-0.55f,-0.51f);
    glVertex2f(-0.45f,-0.51f);
    glVertex2f(-0.5f,-0.-.6f);

    glEnd();

    //////////////////////
    //wave1
     GLfloat x=-0.45f; GLfloat y=-0.8f;
	int i;
	float twicePi = 2.0f * PI;
   GLfloat radius =.05f;
    int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(39, 229, 239);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		  x=-0.45f;  y=-0.81f;


    radius =.05f;


    	glBegin(GL_TRIANGLE_FAN);
    	glColor3f(0.0f, 0.0f, 1.0f);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

//wave1


//wave2
      x=-0.55f;  y=-0.8f;

   radius =.05f;


    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(39, 229, 239);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		  x=-0.55f;  y=-0.81f;


    radius =.05f;


    	glBegin(GL_TRIANGLE_FAN);
    	glColor3f(0.0f, 0.0f, 1.0f);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

//wave2


//wave3
      x=-0.65f;  y=-0.8f;

   radius =.05f;


    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(39, 229, 239);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

		  x=-0.65f;  y=-0.81f;


    radius =.05f;


    	glBegin(GL_TRIANGLE_FAN);
    	glColor3f(0.0f, 0.0f, 1.0f);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();

//wave3
    /////////////////////

     x=-0.35f;  y=-0.6f;  radius =.05f;
	//int i;
	//float twicePi = 2.0f * PI;
    radius =.025f;
   // int triangleAmount = 20;

    	glBegin(GL_TRIANGLE_FAN);
    	glColor3ub(264, 63, 58);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();


glBegin(GL_POLYGON);
    glColor3f(1.0f, 0.0f, 0.0f);
    //glColor3ub(100, 32, 10);
    glVertex2f(-0.4f, -0.7f);
    glVertex2f( -0.32f, -0.7f);
    glVertex2f( -0.35f,  -0.63f);
    //glVertex2f( -0.8f,  -0.7f);
    //glVertex2f(-0.7f,  -0.8f);
    glEnd();


Ship2();

Cloud();
Cloud2();

    glPopMatrix();

    glFlush();
}
int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitWindowSize(800, 620);
   glutInitWindowPosition(50, 50);
   glutCreateWindow("Basic Animation");
   glutDisplayFunc(display);
   init();
   glutKeyboardFunc(handleKeypress);
   glutMouseFunc(handleMouse);
   glutTimerFunc(100, update, 0);
   glutMainLoop();
   return 0;
}
